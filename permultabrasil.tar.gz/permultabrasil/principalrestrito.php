<?php session_start(); ?>
<!doctype html>
<html lang="pt-br">
    <head>
        <title></title>
        <meta charset="UTf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="mntopo.css">
        <script type="text/javascript" src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
        <script type="text/javascript" src="scriptAbas.js"></script>
        <link rel="stylesheet" type="text/css" href="estiloabas.css" /> 
    </head>
    <body>
        <div class="menutop">
            <nav class="menutp">
                <div class="formbsc">
                    <input type="text" class="busca" placeholder="Buscar Anúncios">
                    <input type="submit" name="buscabtn" class="buscabtn" value="Buscar">
                </div>
                <div class="lista">
                <ul>
                    <li><a href="#planos">Planos</a></li>
                    <li><a href="#meus anuncios">Meus Anuncios</a></li>
                    <li><a href="#chat">Chat</a></li>
                    <li><a href="#perfil">Perfil<a>
                                <ul>
                                <li><a href="#meusanuncios">Meus Anúncios</a></li>
                                <li><a href="#chat">Chat</a></li>
                                <li><a href="#Segurancadaconta">Segurança Da Conta</a></li>
                                <li><a href="#notificacoes">Notificações</a></li>
                                <li><a href="#favoritos">Favoritos</a></li>
                                <li><a></a></li>
                                <li><a href="#meuperfil">Meu Perfil</a></li>
                                <li><a href="#gerenciarpagamentos">Pagamentos</a></li>
                                <li><a href="#meucadrastro">Meu Cadrastro</a></li>
                                <li><a href="#sair">Fechar</a></li>
                            </ul>
                    </li>
                </ul>
                    
                    <input class="botao_anunciar" type="submit" value="Anunciar">
                </div>
            </nav>
       
        <div class="TabControl">
    <div id="header">
        <ul class="abas">
            <li>
                <div class="aba">
                    <span>Tab 1</span>      
                </div>
            </li>
            <li>
                <div class="aba">
                    <span>Tab 2</span>
                </div>
            </li>
            <li>
                <div class="aba">
                    <span>Tab 3</span>
                </div>
            </li>
            <li>
                <div class="aba">
                    <span>Tab 4</span>
                </div>
            </li>
        </ul>
    </div>
    <div id="content">
        <div class="conteudo">
            Conteúdo da aba 1
        </div>
        <div class="conteudo">
            Conteúdo da aba 2
        </div>
        <div class="conteudo">
            Conteúdo da aba 3
        </div>
        <div class="conteudo">
            Conteúdo da aba 4
        </div>
    </div>
    </body>
</html>
