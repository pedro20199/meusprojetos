
//cria as variaveis de chamada do modal
var modal = document.querySelector(".modal");
var botao_abrir = document.querySelector(".botao_abrir");
var botao_fechar = document.querySelector(".botao_fechar");
function abrir(){
    modal.classList.toggle("show-modal");
}
//fecha o modal
function windowOnClick(event){
    if(event.target === modal){
        abrir();
    }
}
botao_abrir.addEventListener("click", abrir);
botao_fechar.addEventListener("click", abrir);
window.addEventListener("click", windowOnClick);


