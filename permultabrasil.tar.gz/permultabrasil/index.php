<?php
//Inicia a sessão
session_start();
?>
   
<!DOCTYPE html>
<html lang="pt-BR" dir="ltr">
    <head>
        <meta charset="utf-8">     
        <title></title>
         <link rel="stylesheet" type="text/css" href="menu.css">    
    <link rel="stylesheet" type="text/css" href="modal.css"> 
    <link rel="stylesheet" type="text/css" href="anunciodestaque.css">
    </head>
   
    <body>
        
       
<div class="menutopo">
<nav class="menutp">
  <ul>
    <li><a href="#planos">Planos</a></li>
	<li><a href="#meus anuncios">Meus Anúncios</a></li>
    <li><a href="#chat">chat</a></li>
    
  </ul>
</nav>
    
    <form method="POST" action="valida.php">
          <input type="email" name="login" class="email" placeholder="E-mail">
          <input type="password" name="password" class="senha" placeholder="Senha">
          <input type="submit" class="entrar"  value="Entrar">
            </form>    
    <a href="#modal" class="botao_abrir">Cadastre-se</a>
    </div>
        <div class="menubusca">
            <nav class="menubc">
                <div class="form">
                    <input type="search" class="busca" placeholder="Buscar Anuncios">
                    <input type="submit" class="btnbusca" value="Buscar">
                    </div>
            </nav>
        </div>
        
        
        
        
    <div class="modal">
        <div class="modalprincipral"> <script type="text/javascript" src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
        <script type="text/javascript" src="scriptAbas.js"></script>
        <link rel="stylesheet" type="text/css" href="estiloabas.css" /> 
                <span class="botao_fechar">&times;</span>
           <div  class="form2">
               <form method="POST" action="fazcadastro.php">
                <input type="text" name="apelido" class="apelido" placeholder="Apelido">
                <input type="text" name="email" class="e-mail" placeholder="E-mail">
                <input type="password" name="senha" class="senha1" placeholder="Senha">
                <input type="submit" name="cadrasto" class="cadrastro" value="Cadrastar">
            </form>
               <div class="foto" ></div>
           </div>
        </div>
    </div>
        <div class="anunciosdestaque" title="Foto"></div>
       <script type="text/javascript" src="mostrarmodal.js"></script>   
   
     

    </body>
   
</html>
