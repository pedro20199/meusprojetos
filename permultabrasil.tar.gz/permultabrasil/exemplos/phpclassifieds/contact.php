<?
require("config/header.inc.php");
require("config/config.inc.php");
if (!$special_mode) { print("$menu_ordinary"); }
require ("link_title.php");

if ($submit)
{
 $sql = "select ad_username from $ads_tbl where siteid = $siteid";
 $sql_resultads = mysql_query ($sql);
 $num_ads =  mysql_num_rows($sql_resultads);
 
 for ($i=0; $i<$num_ads; $i++)
 {
      $row = mysql_fetch_array($sql_resultads);
      $email = $row["ad_username"];
 }
// setup variables
$sendto = "$email";
$from = "$epost";
$subject = "$la_email";
$message = "$la_email_body";



$headers = "From: $from\r\n";
// send e-mail
mail($sendto, $subject, $message, $headers);

        


   
?>
<font class='text'><p><b><? echo $la_sent_message ?></b></font>


<?
}
else
{
?>



<form method="post" action="<?php echo $PHP_SELF?>">





<?
	require("config/config.inc.php");
	require("admin/db.php");
	
	$sql = "select ad_username from $ads_tbl where siteid = $siteid";
  $sql_resultads = mysql_query ($sql);
  $num_ads =  mysql_num_rows($sql_resultads);
 
  for ($i=0; $i<$num_ads; $i++)
  {
      $row = mysql_fetch_array($sql_resultads);
      $ad_username = $row["ad_username"];
  }
 
	$sql_eier = "select name from $usr_tbl where email = '$ad_username'";
	$result = mysql_query ($sql_eier);
	


        while ($row = mysql_fetch_array($result))
        {
        	$name_own = $row["name"];
        	
    
        
?>
<input type="hidden" name="name" value="<? echo $name_own ?>">
<input type="hidden" name="siteid" value="<? echo $siteid ?>">

<table border="0" cellspacing="1" width="80%">
  <tr>
    <td width="100%"><h2><? echo $la_kontakt ?></h2>
      <font size="1" face="Verdana"><? print($la_main_message); ?> <b><? echo $name_own ?></b>.<br>
      &nbsp;</font>
      <table border="0" cellspacing="1" width="100%">
        <tr>
          <td width="50%" valign="top"><font size="1" face="Verdana"><? echo $add_user_name ?></font></td>
          <td width="50%" valign="top"><font size="1" face="Verdana"><input type="text" name="navn" size="42" style="font-size: 8pt; font-family: Verdana"></font></td>
        </tr>
        <tr>
          <td width="50%" valign="top"><font size="1" face="Verdana"><? echo $add_user_email ?></font></td>
          <td width="50%" valign="top"><font size="1" face="Verdana"><input type="text" name="epost" size="42" style="font-size: 8pt; font-family: Verdana"></font></td>
        </tr>
        <tr>
          <td width="50%" valign="top"><font size="1" face="Verdana">Message</font></td>
          <td width="50%" valign="top"><textarea rows="5" name="beskjed" cols="32"></textarea></td>
        </tr>
      </table>
      <p><font size="1" face="Verdana"><input type="submit" value="<? echo $la_kontakt ?>" name="submit" style="font-size: 8pt; font-family: Verdana"></font></td>
  </tr>
</table>
</form>

   
<?
};
}
require("config/footer.inc.php");
?>
