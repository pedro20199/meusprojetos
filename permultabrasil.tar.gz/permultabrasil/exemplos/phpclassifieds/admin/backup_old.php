<? require("admheader.php"); ?>
<!-- Table menu -->
<table border="1" cellpadding="3" cellspacing="0" width="100%">
<tr>
		<td bgcolor="lightgrey">
				<font color="black" face="Tahoma,Arial,Helvetica" size="2">
				&nbsp; Backup</font>
		</td>
</tr>
   
<tr bgcolor="white">
		<td width="100%">
				<font face='Verdana' size='1'>
Here you can make a backup of all the sql tables with content AND the config, header, footer and db file. NOTE:  Sql dump will only work with correct set-up mysqldump client. It will run a mysqldump. The backup will be done to 
the <? print("$full_path_to_public_program/admin/backup/"); ?> directory, REMEMBER to make the backup dir world-writeable in order to use this tool<p><b>Note:</b>Do NOT consider this as bulletproof, 100% secure backup, just use this as an additional help to recreate your data. You SHOULD also use other, more secure methods. 
Only successfull backup/copying will be displayed with links and text.<p>

<? 
$backupdir_perm = fileperms("backup/");
if ($backupdir_perm == 16895) 
{
	print("Permissions are set correct: <a href='backup.php?backup=1'><b>Start backup</b></a>");
}
else
{
	print("<font color=red><b>Error:</b><br>Backupdir is not set to chmod 777 (writeable)</font>");
}
?>
<?

//------   Backup of config files ---------
if ($backup == 1)
{

if ( copy ("$full_path_to_public_program/config/config.inc.php", "$full_path_to_public_program/admin/backup/config.inc.php") )
{
	print "<br>Config.inc.php is copied !<br>";
}
else
{
	print "<font color=red>Config.inc.php NOT copied!</font><br>";
}

if ( copy ("$full_path_to_public_program/config/header.inc.php", "$full_path_to_public_program/admin/backup/header.inc.php") )
{
	print "Header.inc.php is copied!<br>";
}
else
{
	print "<font color=red>Header.inc.php NOT copied!</font><br>";
}

if ( copy ("$full_path_to_public_program/config/footer.inc.php", "$full_path_to_public_program/admin/backup/footer.inc.php") )
{
	print "Footer.inc.php is copied!<br>";
}
else
{
	print "<font color=red>Footer.inc.php NOT copied!</font><br>";
}

if ( copy ("$full_path_to_public_program/admin/db.php", "$full_path_to_public_program/admin/backup/db.php") )
{
	print "Db.php is copied!<br>";
}
else
{
	print "<font color=red>Db.php NOT copied!</font><br>";
}



$backup_cat = "mysqldump --opt -c  -full -h $dbhost  -u $dbusr -p$dbpass $datab $cat_tbl >  $full_path_to_public_program/admin/backup/$cat_tbl.sql";
$backup_ads = "mysqldump --opt -c  -full -h $dbhost  -u $dbusr -p$dbpass $datab $ads_tbl >  $full_path_to_public_program/admin/backup/$ads_tbl.sql";
$backup_usr = "mysqldump --opt -c  -full -h $dbhost  -u $dbusr -p$dbpass $datab $usr_tbl >  $full_path_to_public_program/admin/backup/$usr_tbl.sql";
$backup_conf = "mysqldump --opt -c  -full -h $dbhost  -u $dbusr -p$dbpass $datab Config >  $full_path_to_public_program/admin/backup/Config.sql";
$backup_pic = "mysqldump --opt -c  -full -h $dbhost  -u $dbusr -p$dbpass $datab $pic_tbl >  $full_path_to_public_program/admin/backup/$pic_tbl.sql";

$exec=passthru("$backup_cat", $ret_cat);
$exec=passthru("$backup_ads", $ret_ads);
$exec=passthru("$backup_usr", $ret_usr);
$exec=passthru("$backup_conf", $ret_conf);
$exec=passthru("$backup_pic", $ret_pic);

//------   Backup of SQL ---------	
if ($ret_cat==0) 
{
	print("<a href='backup/$cat_tbl.sql'>Download $cat_tbl.sql</a><br>");
	
}
else
{
	print "<font color=red>Error: Category table not copied!</font><br>";
}
if ($ret_ads==0) 
{
	print("<a href='backup/$ads_tbl.sql'>Download $ads_tbl.sql</a><br>");
}
else
{
	print "<font color=red>Error: Ads table not copied!</font><br>";
}
if ($ret_usr ==0) 
{
	print("<a href='backup/$usr_tbl.sql'>Download $usr_tbl.sql</a><br>");
}
else
{
	print "<font color=red>Error: User table not copied!</font><br>";
}
if ($ret_conf==0) 
{
	print("<a href='backup/Config.sql'>Download Config.sql</a><br>");
}
else
{
	print "<font color=red>Error: Config table not copied!</font><br>";
}
if ($ret_pic==0) 
{
	print("<a href='backup/$pic_tbl.sql'>Download $pic_tbl.sql</a><br>");
}
else
{
	print "<font color=red>Error: Picture table not copied!</font><br>";
}
print("<p><b>Done!</b><br>The program is now complete. Please check if you directory contains the files needed.<br>");
print("Above you can download any of the database files to your computer by rightclicking and choose Save Target As.<br>");
}

?>
		</font><p>
	 </td>
</tr>
</table>
<!-- END Table menu -->
<? require("admfooter.php"); ?>