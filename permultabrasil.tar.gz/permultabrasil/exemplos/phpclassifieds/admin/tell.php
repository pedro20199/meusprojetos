<?
if (file_exists("config/config.inc.php")) 
{ 
	include("config/config.inc.php");
	$sql_links = "select * from $ads_tbl";
	$sql_result = mysql_query ($sql_links);
	$annonser =  mysql_num_rows($sql_result);

	$sql_links = "select * from $usr_tbl";
	$sql_result = mysql_query ($sql_links);
	$antall =  mysql_num_rows($sql_result);

	$sql_sites = "select sum(sitehits) from $ads_tbl";
	$result_sites = mysql_query ($sql_sites);
	$num_sites =  mysql_num_rows($result_sites);

	while ($row = mysql_fetch_array($result_sites))
	{
 		$detaljvisninger= $row["sum(sitehits)"];
	}
}
?>