        <select size="1" name="category_wanted" class="tekstfelt">
                     <option selected>Choose category</option>

<?
             /*

         COPYRIGHT

         This program is copyright (c) 2001 by Haugsdal Webtjenester. All re-use of
         part or hole of this program is strictly forbidden.



         ABOUT PHP LINKS

         The PHP Links program is a directory/link program with unlimited sub-categories,
         top level categories and links. It has two user interfaces: One directory for
         the public, and one admin area only for you.




         LICENCE

         This program is free for non-commercial use, and is not supported by email.
         You agree to hold Haugsdal Webtjenester, or people in or associated to the company,
         blameless for any errors, problems, damages or any unwanted happening because of use
         of this program.

         Companies need to buy a licence by wire-transfer. Then you get support by
         email, and one hour free custom programming. Example of custom programming could
         be f.example picture upload, rating functions etc.

         There is/or will be set up a forum that I and other users may use to ask
         questions for free.

         Read licence.txt for complete licence terms.

         */


$sql_select = "select * from categories";
$result = mysql_query ($sql_select);

while ($row = mysql_fetch_array($result)) {

        $catid_n = $row["catid"];

        $catname = $row["catname"];


 print("<option value='$catid_n'");
   if ($catid_n == $catid)
  {
       print("selected");
  }
print(">$catname</option>");

};





?>
</select>
<?
$catname = 0;
?>