<html>
<head></head>
<?
if (file_exists("../config/config.inc.php")) 
{
 include("../config/config.inc.php");
} 
?>
<style>
A:link { color: blue; text-decoration: underline}
A:visited { color: blue; text-decoration: underline}
A:hover { color: red; text-decoration: underline}
</style>
<body>
<p>
<table>
<tr>
<td colspan=3>
<!-- Header rows -->

<table border="0" cellpadding="3" width="100%" cellspacing="3" bgcolor="#FFFFFF">
  <tr>
    <td width="297" colspan="3"><a href="http://www.deltascripts.com/"><img height="23" src="logo.gif" width="140" align="left" border="0"></a>
    </td>
    <td width="431" colspan="5">
      <p align="right"><font face="Verdana" size="1">PHP Classifieds <a href="">V6.03</a></font></td>
  </tr>
  <tr><td></td>
  </tr>
</table>
<!-- END Header rows-->
</td>
</tr>

<tr>
<td valign=top width=130 bgcolor="#FFFFFF" height="100%">

  <!-- Table menu -->
	<table border="1" cellpadding="3" cellspacing="0" width="130">
  
	<tr>
			<td bgcolor="lightgrey"><font color="black" face="Tahoma,Arial,Helvetica" size="2">&nbsp; Menu</font></td>
  </tr>
   
	<tr bgcolor="white">
	<td width="200">
			 <font face="Verdana" size="1">
			  &nbsp;<a href = "index.php">Main admin</a><br>
				&nbsp;<a href = "ads.php">Ads admin</a><br>
			  &nbsp;<a href = "add_cat.php">Category admin</a><br>
			  &nbsp;<a href = "email.php">Email members</a><br>
			  &nbsp;<a href = "setconfig.php">Settings</a><br>
			  &nbsp;<a href = "extra.php">Extra fields</a><br>				
			  <? if (!$auto)
				{
				print "&nbsp;<a href = '../update.php'>Update counter</a><br>";
				}
				?>
			  &nbsp;<a href = "stats.php">View stats</a><br>
			  &nbsp;<a href = "list_users.php">View users</a><br>
			  &nbsp;<a href = "../" target="_blank">View frontpage</a><br>
			  &nbsp;<a href = "backup.php">Backup</a><br>
	    </font><p>
	 </td>
   </tr>
   </table>

   <!-- END Table menu -->
</td>
<td align=left valign=top width=100%>