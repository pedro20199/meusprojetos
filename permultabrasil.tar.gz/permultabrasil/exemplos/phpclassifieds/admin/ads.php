<? require("admheader.php"); ?>
<!-- Table menu -->
<table border="1" cellpadding="3" cellspacing="0" width="100%">
<tr>
		<td bgcolor="lightgrey">
				<font color="black" face="Tahoma,Arial,Helvetica" size="2">
				&nbsp; Ads admin</font>
		</td>
</tr>
   
<tr bgcolor="white">
		<td width="100%">
				<font face='Verdana' size='1'>
				<?
				print("$list_message");
				print("<p>");
				?>
				<p>
				<form method="post" action"<? echo $PHP_SELF?>">
				<?php require("list_admin.php"); ?>
				<input type=submit class=tekstfelt value=<? echo $check ?>>
				</form>
				<?
				if ($del AND $siteid)
				{
				 	 include("../functions.php");	
					 delete_ads("$siteid");
				}
				?>	 
				<table border="0" cellpadding="2" cellspacing="2" width="100%">
			 	<tr>
  		 		 <td bgcolor="#E6E6E6"><font face='Verdana' size='1'><? echo $title ?></font></td>
  				 <td bgcolor="#E6E6E6"><font face='Verdana' size='1'><? echo $category ?></font></td>
  				 <td bgcolor="#E6E6E6"><font face='Verdana' size='1'><? echo $la_view ?></font></td>
  				 <td bgcolor="#E6E6E6"><font face='Verdana' size='1'><? echo $delete_button ?></font></td>
				</tr>
				<?
				if (!$sitecatid)
				{
					 $sitecatid = "%%";
					 $limit = "limit 10";
				} 
				
				$sql_select = "select siteid,sitetitle,sitedescription,sitedate,sitecatid,sitehits,sitevotes, catid, catname from $ads_tbl, $cat_tbl where catid=sitecatid AND sitecatid like '$sitecatid' order by siteid desc $limit";
				if ($debug) { print("$sql_select");}
        $result = mysql_query ($sql_select);

        while ($row = mysql_fetch_array($result))
        {
				 			$siteid = $row["siteid"];
							$sitetitle = $row["sitetitle"];
        			$sitedescription = $row["sitedescription"];
        			$siteurl = $row["siteurl"];
        			$sitedate = $row["sitedate"];
        			$sitecatid = $row["sitecatid"];
        			$sitehits = $row["sitehits"];
        			$sitevotes = $row["sitevotes"];
         			$catid = $row["catid"];
              $catname = $row["catname"];

							print("<tr>");
							print("<td width='30%'><font face='verdana' size='1'>$sitetitle</font></td>");
							print("<td width='17%'><font face='verdana' size='1'><a href='../index.php?kid=$sitecatid&catname=$catname' target=\"_blank\">$catname</a></font></td>");
							print("<td width='17%'><font face='verdana' size='1'><a href='../detail.php?annid=$siteid' target=\"_blank\"><u>View</u></a></font></td>");
							print("<td width='17%'><font face='verdana' size='1'><a href='ads.php?siteid=$siteid&del=1'><u>$delete_button</u></a></font></td>");
							print("</tr>");
			 }
			 print("</table>");
			 ?>
	     </font><p>
	 </td>
</tr>
</table>
<!-- END Table menu -->
<? require("admfooter.php"); ?>
