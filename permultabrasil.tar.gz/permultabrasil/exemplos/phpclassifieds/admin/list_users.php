<? require("admheader.php"); ?>
<!-- Table menu -->
<table border="1" cellpadding="3" cellspacing="0" width="100%">
<tr>
		<td bgcolor="lightgrey">
				<font color="black" face="Tahoma,Arial,Helvetica" size="2">
				&nbsp; Users</font>
		</td>
</tr>
   
<tr bgcolor="white">
		<td width="100%">
				<font face='Verdana' size='1'>
<?
if (empty($offset)) 
{
 $offset=0;
}
$limit = 20;
require("../functions.php");
?>

		
<?
print("<table width='100%'>");
if ($delete AND $userid)
{
  	 delete_user("$userid");
}

 	 	$numresults = mysql_query("select * from $usr_tbl order by email desc");
 	  $numrows=mysql_num_rows($numresults);
		
		$sql_links = "select * from $usr_tbl order by email desc limit $offset,$limit";
		//$sql_links = "select * from $usr_tbl order by email desc limit $fra, $til";
		$sql_result = mysql_query ($sql_links);
		$num_links =  mysql_num_rows($sql_result);
		$color = "#eeeeee";
		
		
		for ($i=0; $i<$num_links; $i++)
		{
	    		$row = mysql_fetch_array($sql_result);
      			$userid = $row["email"];
      			$name = $row["name"];
      			$email = $row["email"];
      			$registered  = $row["registered"];
			$num_ads = $row["num_ads"];
			$registered = $row["registered"];
			$year=substr($row[registered],0,4);
			$month=substr($row[registered],4,2);
			$day=substr($row[registered],6,2);
			$regdate = "$day.$month.$year";
			$sql_result99 = mysql_query ("select siteid from $ads_tbl where ad_username = '$email'");
			$row99 = mysql_fetch_array($sql_result99);
 			$siteid = $row99["siteid"];
			print("<tr><td><font face='Verdana' size='1'><a href='../search.php?siteid=$siteid&adv=1'>$userid</a></font></td><td><font face='Verdana' size='1'>$name</font></td><td><font face='Verdana' size='1'>$regdate</font></td><td><font face='Verdana' size='1'>$num_ads</font></td><td><font face='Verdana' size='1'><a href='list_users.php?userid=$userid&delete=1'>Delete</a></font></td></tr>");
		}
print("</table>");
?>
<p>
<table border="0" cellpadding="1" cellspacing="0" width="100%">
<tr><td><font face='Verdana' size='1'>Results:</font></td></tr>
<tr><td>
<?
if ($offset==1) { // bypass PREV link if offset is 0
    $prevoffset=$offset-20;
    print "<font face=Verdana size=1><a href=\"$PHP_SELF?offset=$prevoffset$URLNEXT\">PREV</a> </font>\n";
}

// calculate number of pages needing links
$pages=intval($numrows/$limit);

// $pages now contains int of pages needed unless there is a remainder from division
if ($numrows%$limit) {
    // has remainder so add one page
    $pages++;
}

for ($i=1;$i<=$pages;$i++) { // loop thru
    $newoffset=$limit*($i-1);
    print "<font face=Verdana size=1><a href=\"$PHP_SELF?offset=$newoffset$URLNEXT\">$i</a> </font>\n";
}

// check to see if last page
if (!(($offset/$limit)==$pages) && $pages!=1) {
    // not last page so give NEXT link
    $newoffset=$offset+$limit;
    print "<font face=Verdana size=1><a href=\"$PHP_SELF?offset=$newoffset$URLNEXT\">NEXT</a></font>\n";
}
?>
</td></tr></table>

		</font>
	 </td>
</tr>
</table>
<!-- END Table menu -->
<? require("admfooter.php"); ?>