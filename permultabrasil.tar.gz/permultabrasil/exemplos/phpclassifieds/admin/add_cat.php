<? require("admheader.php"); ?>
<!-- Table menu -->
<table border="1" cellpadding="3" cellspacing="0" width="100%">
<tr>
		<td bgcolor="lightgrey">
				<font color="black" face="Tahoma,Arial,Helvetica" size="2">
				&nbsp; Menu</font>
		</td>
</tr>
   
<tr bgcolor="white">
		<td width="100%">
				<font face='Verdana' size='1'>

<form method="post" name="s2" action"<? echo $PHP_SELF ?>">
<table width="100%">
<td valign=top>
<?

if ($mode <> 'new' AND !$add)
{
?>


<table width=100% border=1 cellpadding=0 cellspacing=1><tr><td bordercolor="#FFFFFF">
<b><font face='Verdana' color="black" size='1'>Change categoryname/description</font></font></b>
</td></tr><tr><td bordercolor="#FFFFFF">
<font face='Verdana' size='1'>
If you want to give a new name, image or description to a category, select the category below and push Modify. You will then see the category name and other details registered on this ad in the Add form below. To save the changes, push <b>UPDATE</b> button below that large form.</font><br>

<?php include("list_admin2.php"); ?>
<input type=submit value=<? echo $mod ?>>

</td></tr></table>
<?
}
?>

</form>


<form method="post" name="s1" action="<?php echo $PHP_SELF?>">
<input type="hidden" name="updateid" value="<?php echo $category_wanted ?>">

<?

$companyregistered = date('d.m.Y');

$sql_select = "select catid,catfatherid,catname,catdescription,catimage,cattpl,allowads from $cat_tbl where catid = '$category_wanted'";
	 if (!$catimage)
	 {
	 			$catimage = 'default.gif';
	 }

	 if ($catfatherid <> 0)
	 {	 
	      		 $string = "select catfullname from $cat_tbl where catid = '$catfatherid'";
						 $result_new = mysql_query ($string);
        		 $row = mysql_fetch_array($result_new);
        		 $catname1 = $row["catname"];
						 $catfullname = $row["catfullname"];
						 
		}
		
		if (!$catfullname)
		{
		 	 $catfullname = $catname_new;
		}
	 	else
		{
			 $catfullname = $catfullname . "/" . $catname_new;
		}
					 
		if (!$catfatherid)
		{
		 	 $catfatherid = 0;
		}

$sql_update = "update $cat_tbl set catfatherid='$catfatherid',catname='$catname_new',catdescription='$catdescription',catimage = '$catimage',cattpl = '$cattpl', allowads = '$allowads', catfullname = '$catfullname' where catid = '$updateid'";
$sql_insert = "insert into $cat_tbl (catfatherid,catname,catdescription,catimage,cattpl,allowads,catfullname) values ($catfatherid,'$catname_new','$catdescription','$catimage','$cattpl','$allowads','$catfullname')";
																 


// }

if ($category_wanted)
{
        $result = mysql_query ($sql_select);


        while ($row = mysql_fetch_array($result))
        {
        $catid = $row["catid"];
        $catfatherid = $row["catfatherid"];
        $catname1 = $row["catname"];
			  $catimage = $row["catimage"];
				$cattpl = $row["cattpl"];
				$allowads = $row["allowads"];
        $catdescription = $row["catdescription"];
				$catfullname = $row["catfullname"];



        }



}

?>




<?php 
print "<font face='Verdana' size='1'><b>$status</b></font>";

if ($mode == 'new' OR $category_wanted)
{ 
?>

<table width="100%">


    <td valign=top><font face=Arial,Helvetica>
<table width=100% border=1 cellpadding=0 cellspacing=1><tr><td bordercolor="#FFFFFF">
<b><font face='Verdana' size='1' color='black'>


<?
if ($category_wanted)
{
	print("<p>Modify earlier registered category (edit mode)<p>");
}
else
{
	print("<p>Add new category<p>");
}
?>


</font></b>
</td></tr><tr><td bordercolor="#FFFFFF">
<table border="0" cellpadding="0" cellspacing="0" width="100%">
  <tr>
    <td width="50%" valign="top"><font face='Verdana' size='1'><? echo $add_cat_title ?></td>
    <td width="50%" valign="top"><font face='Verdana' size='1'>
<input type="text" name="catname_new" size="38" value="<?php echo $catname1 ?>">
      </font>

    </td>
  </tr>
  <tr>
    <td width="50%" valign="top"><font face='Verdana' size='1'><? echo $add_cat_father ?></td>
    <td width="50%" valign="top"><font face='Verdana' size='1'>
    <?
		include("drop.php");

     if ($catfatherid == 0)
     {
      print("<font color=red><small>$top_level_message</small></font>");
     }
    ?>
      </font>

    </td>
  </tr>


    <tr>
    <td width="50%" valign="top"><font face='Verdana' size='1'><? echo $add_cat_description ?></font></td>
    <td width="50%" valign="top"><font face='Verdana' size='1'><textarea  rows="4" name="catdescription" cols="28"><?php echo $catdescription ?></textarea>
     </font>

    </td>
  </tr>
	
	   <tr>
    <td width="50%" valign="top"><font face='Verdana' size='1'>Allow ads ?</font></td>
    <td width="50%" valign="top"><font face='Verdana' size='1'>
		<?
		print "<input type='checkbox' name='allowads' ";
		if ($allowads)
		{
		 	 print "checked";
		}
		print ">";
		?>
     </font>

    </td>
  </tr>

  <tr>
    <td width="50%" valign="top"><font face='Verdana' size='1'>Category image</td>
    <td width="50%" valign="top"><font face='Verdana' size='1'>
<input type="text" name="catimage" size="38" value="<?php echo $catimage ?>">
      </font>

    </td>
  </tr>
	
	  <tr>
    <td width="50%" valign="top"><font face='Verdana' size='1'>Category template</td>
    <td width="50%" valign="top"><font face='Verdana' size='1'>
		<?
		print "<select name='cattpl'>";
		$sql = "select * from template order by tplid";
		if ($cattpl <> "")
		{
		print "<option selected>$cattpl</option><option value=''>None</option>";
		}
		else
		{
		print "<option value='' selected>None</option>";
		}
		$result = mysql_query ($sql);
		while ($row = mysql_fetch_array($result)) {
 		$name = $row[name];
		print "<option>$name</option>";
		} 
		print "</select> <a href='extra.php'>(optional)</a>";
		?>
      </font>

    </td>
  </tr>
	
	
<tr><td colspan=2>
<?
if ($category_wanted)
{
print("<input type=\"submit\" class=\"tekstfelt\" name=\"add\" value=\"Update $catname1\">");
print("&nbsp;&nbsp;<input type=\"submit\" name=\"delete\" class=\"tekstfelt\" style=\"background color:#FF8080;\" value=\"$delete_button $catname1 category\">");
}
else
{
print("<input type=\"submit\" name=\"add\" value=\"Create category\">");
}
?>
</td></tr>


  <tr>
    <td width="100%" valign="top" colspan="2" bgcolor="#FFFFFF"><font face=Arial,Helvetica>


      </font>

    </td>
  </tr>
</table>



      </font>

</td></tr>


</table>


<?
}
?>
       </form>

</table>


<?
if ($mode == 'new' OR $category_wanted)
{ 
?>

<font face='Verdana' size='1'>
Name = Name of the category<br>
this is a category below = Under what category should this category be in?<br>   
Description = Either a description of the category, OR a Yahoo style subcategory list made up by hyperlinks to
the sub-dirs. If you have a category Cars, and have subdirs Ford, Volvo, you type in a html hyperlink to the Ford and Volvo categories.<br>
</font>


<?
}
print "<font face='Verdana' size='1'><a href='add_cat.php?mode=new'>Add new category</a></font>";

if ($delete)
{
           
					 $sql_delete = "delete from $cat_tbl where catid = $updateid";
					 $result = mysql_query ($sql_delete);
           $status = "$deleted";
}

if ($add)
{
 	 
	 if ($updateid)
   {
         if ($catname_new)
         {
				
						
						$result = mysql_query ($sql_update);
           	$status = $updated_site;
           	print("<p>Updated category $add_cat_title: $catname_new<p><a href='add_cat.php'>Go back</a><p>");
         }
         else
         {
         print("<font color=red><b>Error</b><br>You must type in the NEW categoryname. Since you are i modify mode, the category will get renamed. It makes no sense to add a blank category.</font>");
         }
   }
   else
   {
           
        if ($catname_new)
        {
					
					$result = mysql_query ($sql_insert);
          $status = $registered_site;
					print("<p>Created $add_cat_title: $catname_new<p><a href='add_cat.php'>Go back</a><p>");
					$catid = mysql_insert_id();
				}
				else
				{
				 print("<font color=red><b>Error</b><br>You must type in a categoryname to add. It makes no sense to add a blank category.</font>");
				}
   }
	 
}




?>
		</font><p>
	 </td>
</tr>
</table>
<!-- END Table menu -->
<? require("admfooter.php"); ?>