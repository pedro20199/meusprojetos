<?
require("../config/header.inc.php");
require("../config/config.inc.php");
require("../functions.php");	
	
	/*
	$sql_delete = "delete from $ads_tbl where siteid = '$siteid'";
	if ($debug)
	{
	 	 print("$sql_delete");
	}
	$result = mysql_query ($sql_delete);
	*/
	print("$menu<p>");
	//print("$deleted");
	
	delete_ads("$siteid");
	
  	require("../config/footer.inc.php");
?>