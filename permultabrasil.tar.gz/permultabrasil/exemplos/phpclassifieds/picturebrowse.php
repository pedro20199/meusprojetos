<?php
require("config/header.inc.php");	 
require("config/config.inc.php");	 
if (!$special_mode)
{ print("$menu_ordinary<p>"); }
print("<b>$la_picture_gallery</b><br>");
print("<font class='text'>$la_picute_gallery_text</font><p>");
 
function picture($from, $num_res)
{
 				 global $pic_tbl;
				 global $ads_tbl;

	      $query = "select picture,siteid,img_stored from $ads_tbl where picture>0 OR img_stored <> '' order by siteid desc limit $from,$num_res"; 	
				$result = mysql_query ($query);
			
			while ($row = mysql_fetch_array($result)) 
	 		{  	
       			$picture = $row["picture"];
       			$siteid = $row["siteid"];
						$img_stored = $row["img_stored"];
	 	 				
						if ($img_stored <> '') 
						{ 
						  print("<td><a href=\"detail.php?annid=$siteid\"><img border=\"0\" alt=\"Original\" src=\"images/$img_stored\" width=\"106\" height=\"68\" align=\"left\"></a></td>");
						}
						else
						{
						 print("<td><a href=\"detail.php?annid=$siteid\"><img border=\"0\" alt=\"Original\" src=\"get.php?id=$picture\" width=\"106\" height=\"68\" align=\"left\"></a></td>");
	 	 				}
		 }			

}

if (!$side==1)
{
 	 $side = 0;
}

print("<table cellspacing=2><tr>");	
picture($side,5);
print("</tr><tr>");
picture($side+5,5);
print("</tr><tr>");
picture($side+10,5);
print("</tr><tr>");
picture($side+15,5);
print("</tr></table>");
$side_forw = $side+20;
$side_back = $side-20; 

if ($side>20)
{
 print("<a href='picturebrowse.php?side=$side_back'><font class='text'>$la_cat_prev 20</font></a>  ");
}
print("<a href='picturebrowse.php?side=$side_forw'><font class='text'>$la_cat_next 20</font></a>");		
		
require("config/footer.inc.php");	
?>
