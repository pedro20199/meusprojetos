<?php
require("admin/db.php");
$query9 = "select pic_tbl from Config where id=1";
$result9 = MYSQL_QUERY($query9);
$row = mysql_fetch_array($result9);
$pic_tbl = $row["pic_tbl"];
	 
   $query = "select * from $pic_tbl where id=$id"; 	
   $result = @MYSQL_QUERY($query);

    $data = @MYSQL_RESULT($result,0, "bin_data");
    $type = @MYSQL_RESULT($result,0, "filetype");

    Header("Content-type: $type");
    echo $data;
		

?>
