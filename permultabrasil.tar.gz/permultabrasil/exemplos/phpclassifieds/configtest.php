<?
        
print "Current dir is:<br>";
$dir = getcwd ();

if ($dir)
{
        print "It worked: $dir<br>";
}
elseif (!$dir)
{
        print "getcwd didn�t work<br>";
}
$dir = 0;
        
print "Current dir is:<br>";
$dir = exec("pwd");
if ($dir)
{
        print "It worked: $dir <br>";
}
elseif (!$dir)
{ 
        print "pwd didn�t work<br>";
}
$dir = 0;

print "Current dir is: <br>";
$dir = dirname($SCRIPT_FILENAME);
        
if ($dir)
{
        print "It worked: $dir <br>";
}
elseif (!$dir)
{
        print "script_filname dir didn�t work<br>";
}

print "Current dir is:<br>";
$d = $PHP_SELF;
$dir = dirname($d);
if ($dir)
{
        print "It worked $dir <br>";
}
elseif (!$dir)
{
        print "php_self dirname didn�t work<br>";
}
$dir = 0;

print "Install dir  is<br>";
print "$DOCUMENT_ROOT/classifieds";
        
$path = $PATH_INFO;
print $path;  
?>