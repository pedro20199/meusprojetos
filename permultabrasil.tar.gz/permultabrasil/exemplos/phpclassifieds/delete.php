<?
                  require("config.php");
                   require("header.php");
                     print("<p>");

   print("$menu");
              


                  $sql_links = "select * from sites";


                  $sql_result = mysql_query ($sql_links);
                  $num_links =  mysql_num_rows($sql_result);


                  for ($i=0; $i<$num_links; $i++)
                  {
                                $row = mysql_fetch_array($sql_result);
                                $siteid = $row["siteid"];
                                $sitetitle = $row["sitetitle"];
                                $sitedescription = $row["sitedescription"];
                                $siteurl = $row["siteurl"];
                                $sitedate = $row["sitedate"];
                                $sitehits = $row["sitehits"];
                                $sitevotes = $row["sitevotes"];
                                $name = $row["name"];
                                $phone = $row["phone"];
                                $email = $row["email"];
                                $sitevotes = $row["sitevotes"];
                                $adressfield1 = $row["adressfield1"];
                                $adressfield2 = $row["adressfield2"];
                                $catname = $row["catname"];
                                $custom_field_1 = $row["custom_field_1"];
                                $custom_field_2 = $row["custom_field_2"];
                                $custom_field_3 = $row["custom_field_3"];
                                $custom_field_4 = $row["custom_field_4"];
                                $custom_field_5 = $row["custom_field_5"];
                                $custom_field_6 = $row["custom_field_6"];
                                $custom_field_7 = $row["custom_field_7"];
                                $custom_field_8 = $row["custom_field_8"];
                                $picture = $row["picture"];
                                   $expiredate = $row["expiredate"];
                                $dates= "$sitedate";
                                $today = date("d.m.Y");


                                // Change the Dates to meet your needs
                                $dy =  date("d",time($dates));
                                $mn =  date("m",time($dates));
                                $yr = date("Y",time($dates));

                                //$expire = strftime("%d.%m.%Y", mktime(0,0,0,$mn,$dy+$delete_after_x_days,$yr));






                                if ($today == $expiredate)
                                {
                                    $result=MYSQL_QUERY("delete from sites where siteid=$siteid");
                                    $result2=MYSQL_QUERY("delete from pictures where pictures_siteid=$siteid");

                                }






                           }
                         // End fetch

                         Print("All ads expired is now deleted.");

?>


<?
                    require("footer.php");
?>