<?
session_start( );
		 
if (!$siteid)
{
	$siteid = $annid;
}
require("config/header.inc.php");
require("config/config.inc.php");
require("functions.php");
print("<table>");
$sql_links = "select * from $ads_tbl, $cat_tbl, $usr_tbl where catid=sitecatid AND ad_username = $usr_tbl.email AND siteid=$siteid";

$sql_result = mysql_query ($sql_links);
$num_links =  mysql_num_rows($sql_result);

for ($i=0; $i<$num_links; $i++)
{
	$row = mysql_fetch_array($sql_result);
        $siteid = $row["siteid"];
        $sitetitle = $row["sitetitle"];
        $sitedescription = $row["sitedescription"];
				$userid = $row["userid"];
        $sitedate = $row["sitedate"];
        $sitehits = $row["sitehits"];
        $sitevotes = $row["sitevotes"];
        $name = $row["name"];
        $phone = $row["phone"];
        $email = $row["email"];
        $sitevotes = $row["sitevotes"];
        $adressfield1 = $row["adressfield1"];
        $adressfield2 = $row["adressfield2"];
        $catname = $row["catname"];
        $catid = $row["catid"];
        $kid = $row["catid"];
	      $expiredate = $row["expiredate"];
        $custom_field_1 = $row["custom_field_1"];
				$custom_field_2 = $row["custom_field_2"];
				$custom_field_3 = $row["custom_field_3"];
				$custom_field_4 = $row["custom_field_4"];
				$custom_field_5 = $row["custom_field_5"];
				$custom_field_6 = $row["custom_field_6"];
				$custom_field_7 = $row["custom_field_7"];
				$custom_field_8 = $row["custom_field_8"];
				$cattpl = $row["cattpl"];	
				$datestamp = $row["datestamp"];
				$picture = $row["picture"];
				$hide_email = $row["hide_email"];
				$img_stored = $row["img_stored"];
				$year=substr($row[datestamp],0,4);
				$month=substr($row[datestamp],4,2);
				$day=substr($row[datestamp],6,2);
				$sitedate1 = "$day.$month.$year";
	
	while ($counter < 15)
	{
	 			$counter = $counter + 1; 
				$fieldnumber = "f" . $counter;
				$fieldid[$counter] = $row["$fieldnumber"];
	}
	find ("$year", "$month", "$day", "$delete_after_x_days");

	if (!$special_mode) { print("$menu_ordinary"); }
	require("link_title.php");
	?>
	<script LANGUAGE="JavaScript">
	function openWin(URL) { aWindow=window.open(URL,"Stort_bilde","toolbar=no,width=400,height=300,status=no,scrollbars=no,resize=no,menubars=no");
	}
	function openWin2(URL) {
aWindow=window.open(URL,"Stort_bilde","toolbar=no,width=400,height=350,status=no,scrollbars=no,resize=no,menubars=no");
																																																											 }
	</script>
	<h2><? echo $sitetitle ?></h2></p>

	<table border="0" cellpadding="0" cellspacing="0" width="90%">
  <tr>

<? 
if ($picture > 0)
{
  require("config/config.inc.php");
  print("<td valign=top><a href=\"javascript:openWin('large_picture.php?id=$picture')\"><img border=\"0\" alt=\"Klikk for stort bilde\" src=\"get.php?id=$picture\" width=\"106\" height=\"68\" align=\"left\"></a></td>");
}
elseif ($img_stored <> '')
{
  print("<td valign=top><a href=\"javascript:openWin('images/$img_stored')\"><img border=\"0\" alt=\"Klikk for stort bilde\" src=\"images/$img_stored\" width=\"106\" height=\"68\" align=\"left\"></a></td>");
}
else
{
  $colsp = "colspan=2";
}
?>

  <td <? echo $colsp ?> valign=top><? print("<font face='Verdana' size='1'>$sitedescription</font>"); ?></td>
		
  </tr>
  <tr>
    <td><br>
    </td>
    <td></td>
  </tr>
	<tr>
		<td colspan=2><b><font face="Verdana" size="1" valign="top"><? echo $general_details ?></b></font></td>	
	</tr>
	
  <tr>
    <td><font face="Verdana" size="1"><? echo $sold_by_text?></td>
    <td><font face="Verdana" size="1"><? echo $name ?></td>
  </tr>
  <tr>
    <td><font face="Verdana" size="1"><? echo $add_user_email ?></td>
    <td><font face="Verdana" size="1">
<?

if ($email)
{
	if ($hide_email == 1)
	{
		print "<a href='contact.php?siteid=$siteid'>$la_contact_sale</a>";
	}
	else
	{
		print "<a href='mailto:$email'>$email</a>";
	}
}
else
{
		print "Call !";
}
?>

</td>
  </tr>
<?
if ($adressfield1 OR $adressfield2)
{  
    print("<tr>");
    print("<td><font face='Verdana' size='1'>$location_text</td>");
    print("<td><font face='Verdana' size='1'>$adressfield1, $adressfield2</td>");
    print("</tr>");
}
?>
<?  
if ($phone)
{
	  print("<tr>");
    print("<td><font face='Verdana' size='1'>$add_user_phone</td>");
    print("<td><font face='Verdana' size='1'>$phone</td>");
    print("</tr>");
}
?>	
<?
if ($custom_field_1_text)
{
    print("<tr>");
    print("<td><font face='Verdana' size='1'>$custom_field_1_text</td>");
    print("<td><font face='Verdana' size='1'>$custom_field_1</td>");
    print("</tr>");

}

if ($custom_field_2_text)
{
    print("<tr>");
    print("<td><font face='Verdana' size='1'>$custom_field_2_text</font></td>");
    print("<td><font face='Verdana' size='1'>$custom_field_2</font></td>");
    print("</tr>");

}

if ($custom_field_3_text)
{
    print("<tr>");
    print("<td><font face='Verdana' size='1'>$custom_field_3_text</font></td>");
    print("<td><font face='Verdana' size='1'>$custom_field_3</font></td>");
    print("</tr>");

}
if ($custom_field_4_text)
{
    print("<tr>");
    print("<td><font face='Verdana' size='1'>$custom_field_4_text</font></td>");
    print("<td><font face='Verdana' size='1'>$custom_field_4</font></td>");
    print("</tr>");

}
if ($custom_field_5_text)
{
    print("<tr>");
    print("<td><font face='Verdana' size='1'>$custom_field_5_text</font></td>");
    print("<td><font face='Verdana' size='1'>$custom_field_5</font></td>");
    print("</tr>");

}
if ($custom_field_6_text)
{
    print("<tr>");
    print("<td><font face='Verdana' size='1'>$custom_field_6_text</font></td>");
    print("<td><font face='Verdana' size='1'>$custom_field_6</font></td>");
    print("</tr>");

}
if ($custom_field_7_text)
{
    print("<tr>");
    print("<td><font face='Verdana' size='1'>$custom_field_7_text</font></td>");
    print("<td><font face='Verdana' size='1'>$custom_field_7</font></td>");
    print("</tr>");

}
if ($custom_field_8_text)
{
    print("<tr>");
    print("<td><font face='Verdana' size='1'>$custom_field_8_text</font></td>");
    print("<td><font face='Verdana' size='1'>$custom_field_8</font></td>");
    print("</tr>");
}


$string = "select * from template where name = '$cattpl'";
$result = mysql_query ($string);
$row = mysql_fetch_array($result); 

while ($field < 15)
{
 
 $field = $field + 1;
 $fieldname = "f" . $field;
 $tmpfield1 = "f" . $field . "_caption";
 $tmpfield2 = "f" . $field . "_type";
 $tmpfield3 = "f" . $field . "_mandatory";
 $tmpfield4 = "f" . $field . "_length";
 $tmpfield5 = "f" . $field . "_filename";
 
 $caption = $row["$tmpfield1"];
 $type = $row["$tmpfield2"];
 $mandatory = $row["$tmpfield3"];
 $length = $row["$tmpfield4"];
 $filen = $row["$tmpfield5"];
 
 if ($fieldid[$field])
 {
    print("<tr>");
    print("<td><font face='Verdana' size='1'>$caption</font></td>");
    print("<td><font face='Verdana' size='1'>$fieldid[$field]</font></td>");
    print("</tr>");
 }
}






?>

 <tr>
    <td><br>
    </td>
    <td></td>
  </tr>

  <tr>
    <td></td>
    <td></td>
  </tr>

  <tr>
    <td colspan=2><b><font face="Verdana" size="1"><? echo $ad_details_text ?></b></font></td>

  </tr>
  <tr>
    <td><font face='Verdana' size='1'>Ad id</td>
    <td><font face="Verdana" size="1"><? echo $siteid ?></td>
  </tr>
  <tr>
    <td><font face="Verdana" size="1"><? echo $ad_views ?>&nbsp;</td>
    <td><font face="Verdana" size="1"><? echo $sitehits ?></td>
  </tr>
  <tr>
    <td><font face='Verdana' size='1'><? echo $ad_expire ?></td>
    <td><b><font face="Verdana" size="1"><? echo $expire_date ?><b></td>
  </tr>
  <tr>
    <td><font face="Verdana" size="1"><? echo $date_added ?></td>
    <td><font face="Verdana" size="1"><? echo $sitedate1 ?></td>
  </tr>
</table>
<p>
<hr size="1" align="left" width="98%">
                                        

<font size="2">
<?
print("<a href='index.php?kid=$kid&catname=$catname'>$la_similar</a>&nbsp;&nbsp;");
print("<a href='search.php?siteid=$siteid&adv=1'>$la_similar_ads</a>&nbsp;&nbsp;");
print("<a href='contact.php?siteid=$siteid'>$la_contact_sale</a>&nbsp;&nbsp;");
print("<a href='member_login.php?userid=$userid'>$la_edit</a>&nbsp;&nbsp;");
print("<a href='member_login.php?userid=$userid'>$la_delete</a>&nbsp;&nbsp;");
print("<a href=\"javascript:openWin2('tellafriend.php?id=$siteid&adtitle=$sitetitle')\">$la_tell_a_friend</a>");
?>
<p><input type="image" src="print.gif" name="submit" onclick="window.print()">
</small>
<?
}
$tell=$sitehits+1;
$s = "UPDATE $ads_tbl set sitehits=$tell,datestamp='$datestamp' where siteid=$siteid";
$result1=MYSQL_QUERY($s);

require("config/footer.inc.php");
?>