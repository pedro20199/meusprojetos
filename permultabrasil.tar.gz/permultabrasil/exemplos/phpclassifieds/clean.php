<?
 	
	
	// First we find the latest registered user
	
	$sql_latest = "select * from $usr_tbl order by registered desc limit 1";

	$sql_latest_result = mysql_query ($sql_latest);
  $latest =  mysql_num_rows($sql_latest_result);


  for ($i=0; $i<$latest; $i++)
  {
   		$row = mysql_fetch_array($sql_latest_result);
			$latest_userdate = $row["registered"];
	}
	
	// Then we find out if we can delete a user...
	
	$sql_siste = "select * from $usr_tbl order by registered";


	$sql_siste_result = mysql_query ($sql_siste);
  $num_links =  mysql_num_rows($sql_siste_result);


  for ($i=0; $i<$num_links; $i++)
  {
   		$row = mysql_fetch_array($sql_siste_result);
			$userid = $row["userid"];
			$name = $row["name"];
			$registered = $row["registered"];
			//substr($sitetitle2, 0, 10);
			//	$aar = substr($registered, 0, 4); 
      //  $maned = substr($registered, 4, 2); 
      //  $dag = substr($registered, 6, 2); 

			//print("$dag - $maned - $aar<br>");
			//print("$name - $registered<br>");
			$date_new = $latest_userdate-90;
			if ($num_ads == 0 AND (($registered) < ($date_new)))
			{
			 	 			print("Deleted : $userid - $registered - ($date_new)<br>");
							$count  = $count + 1;
	
			}
			
	}
	// print("$count users deleted.");
	
	
	
?>	