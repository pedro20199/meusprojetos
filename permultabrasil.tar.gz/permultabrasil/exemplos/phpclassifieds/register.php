<?
session_start();
include_once("config/header.inc.php");
include_once("config/config.inc.php");
include_once("functions.php");
if (!$special_mode)
{ print("$menu_ordinary<p>"); }
print("<h2>$name_of_site</h2>");

if ($submit)
{
 		$name = strip_tags ("$name");
 		$email = strip_tags ("$email");
		$usr_1 = strip_tags ("$usr_1");
		$usr_2 = strip_tags ("$usr_2");
		$usr_3 = strip_tags ("$usr_3");
		$usr_4 = strip_tags ("$usr_4");
		$usr_5 = strip_tags ("$usr_5");
		
		$result = mysql_query ("select * from $usr_tbl where email = '$email'");
		if (mysql_num_rows($result)>0)
		{
		 	 print "<font color=red>$la_error_msg20</font><br>";
			 $stop = 1;
		}
		else
		{
		 	 	if (ereg("^[a-zA-Z0-9_\.\-]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]+$", $email))
			 {
			 	$stop = 0;
			 }
			 else
			 {
			 	print "<font color=red>$la_error_msg21</font><br>";
				$stop = 1;
			 }
			 if (($passwd <> $passwd2) OR $passwd == '' OR $passwd2 = '')
			 {
			 	print "<font color=red>$la_error_msg22</font><br>";
				$stop = 1;
			 }
			 if (!$stop)
			 {
			 		$password = $passwd;
					$sql_insert = "insert into $usr_tbl (password_enc, email, name,emelding,hide_email,usr_1,usr_2,usr_3,usr_4,usr_5) values (password('$password'), '$email', '$name', '$emelding', '$hide_email','$usr_1','$usr_2','$usr_3','$usr_4','$usr_5')";
			 		$result = mysql_query($sql_insert);
			 		//print "$sql_insert";
			 		if ($result)
			 		{
					$valid_user = $email;
					session_register("valid_user");
				
					print "<b>$la_successreg</b><br>";
			 		print "$la_successreg2<p>";		
					print "<a href='member.php'>$la_successreg3</a>.";
					
// setup variables
$sendto = "$email";
$from = "$from_adress";
$subject = "$subjectfield_email";
$message = "$messagefield_email";
$headers = "From: $from\r\n";
// send e-mail
mail($sendto, $subject, $message, $headers);

			 		}
			 		else
			 		{
			 		 print "Error";
			 		}
			}
} }

if (!$submit OR ($submit AND $stop))
{
 	 if (!$submit)
	 {
?>
	
	<font class='text'>
  <?
	print "$la_why";
	?>
</font>
<? } ?>
<form method=post action="register.php">
 <table width="100%" cellspacing="0">
   <tr>
     <td><font class='text'><? echo $la_mailaddress ?>;</font></td>
     <td><input type=text name=email class=tekstfelt size=30 maxlength=100> <font color=red>*</font></td></tr>
   <tr>
     <td><font class='text'><? echo $la_fullname ?>:</font></td>
     <td valign=top><input type=text name=name class=tekstfelt size=16 maxlength=16> <font color=red>*</font></td></tr>
   <tr>
     <td><font class='text'><? echo $la_pass1 ?>:</font></td>
     <td valign=top><input type=password name=passwd class=tekstfelt size=16 maxlength=16> <font color=red>*</font></td></tr>
   <tr>
     <td><font class='text'><? echo $la_pass2 ?>:</font></td>
     <td><input type=password class=tekstfelt name=passwd2 size=16 maxlength=16> <font color=red>*</font></td></tr>
   <tr>
	 
	 <?
	 if ($usr_1_text)
	 {
   	print("<tr>");
		print("<tr>");
  	print("<td width=\"50%\" valign=\"top\"><font class='text'>$usr_1_text</td>");
  	print("<td width=\"50%\" valign=\"top\"><font face=Arial,Helvetica>");
  	print("<input type=\"text\" name=\"usr_1\" size=\"29\" class='tekstfelt' value=\"$usr_1\">");
  	print("</font>");
  	print("</td>");
  	print("</tr>");
	 }
		?>
		
	 <?
	 if ($usr_2_text)
	 {
   	print("<tr>");
		print("<tr>");
  	print("<td width=\"50%\" valign=\"top\"><font class='text'>$usr_2_text</td>");
  	print("<td width=\"50%\" valign=\"top\"><font face=Arial,Helvetica>");
  	print("<input type=\"text\" name=\"usr_2\" size=\"29\" class='tekstfelt' value=\"$usr_2\">");
  	print("</font>");
  	print("</td>");
  	print("</tr>");
	 }
		?>
		
		<?
	 if ($usr_3_text)
	 {
   	print("<tr>");
		print("<tr>");
  	print("<td width=\"50%\" valign=\"top\"><font class='text'>$usr_3_text</td>");
  	print("<td width=\"50%\" valign=\"top\"><font face=Arial,Helvetica>");
  	print("<input type=\"text\" name=\"usr_3\" size=\"29\" class='tekstfelt' value=\"$usr_3\">");
  	print("</font>");
  	print("</td>");
  	print("</tr>");
	 }
		?>
		
		<?
	 if ($usr_4_text)
	 {
   	print("<tr>");
		print("<tr>");
  	print("<td width=\"50%\" valign=\"top\"><font class='text'>$usr_4_text</td>");
  	print("<td width=\"50%\" valign=\"top\"><font face=Arial,Helvetica>");
  	print("<input type=\"text\" name=\"usr_4\" size=\"29\" class='tekstfelt' value=\"$usr_4\">");
  	print("</font>");
  	print("</td>");
  	print("</tr>");
	 }
		?>
		
		<?
	 if ($usr_5_text)
	 {
   	print("<tr>");
		print("<tr>");
  	print("<td width=\"50%\" valign=\"top\"><font class='text'>$usr_5_text</td>");
  	print("<td width=\"50%\" valign=\"top\"><font face=Arial,Helvetica>");
  	print("<input type=\"text\" name=\"usr_5\" size=\"29\" class='tekstfelt' value=\"$usr_5\">");
  	print("</font>");
  	print("</td>");
  	print("</tr>");
	 }
		?>
	 
	 
	 	 <td valign=top><font class='text'><? echo $la_ne ?>:</font></td>
	 	 <td><font class='text'><input type="checkbox" name="emelding" value="1"><? echo $la_no_email_please ?></font><br>
		 <font class='text'><input type="checkbox" name="hide_email" value="1"><? echo $la_hide_email ?></font></td>
	 </tr>
	 <tr>
     <td colspan=2 align=left>
     <input type=submit name=submit value="<? echo $la_reg ?>"></td></tr>
 </table>
<?
}
include_once("config/footer.inc.php");

?>
</form>