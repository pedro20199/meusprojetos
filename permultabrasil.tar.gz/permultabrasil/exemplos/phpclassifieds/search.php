<?
require("config/header.inc.php");
require("config/config.inc.php");
if (!$special_mode)
{ print("<p>$menu_ordinary<p>"); }

print ("<p><p><a href=''>$home</a><p>");

if (!$searchword AND !$adv)
{

?>
<table border="0" cellpadding="2" cellspacing="0" width="60%">
  <tr>
    <td><font class='text'><? echo $la_search ?></font></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td><form action="search.php" method="post">
  <table cellSpacing="0" border="0" width="100%">

       
      <tr>
        <td bgColor="#000000">
          <table cellSpacing="0" cellPadding="3" border="0" width="100%">
            <tbody>
              <tr>
                <td width="100%" bgColor="#EAEAEA"><font size="2"><input name="searchword" size="20" style="FONT-SIZE: 8pt" size="1"><input type="submit" value="Search" style="FONT-SIZE: 8pt" size="1">
                  <? echo $la_s_category ?>
                  
                  <?
                  	require("list_hovedkat.php");
                  ?>
                  
                    <? $la_s_num_res ?><select style="FONT-SIZE: 8pt" size="1" name="limit">
                    <option value="10" selected>10</option>
                    <option value="15">15</option>
                    <option value="20">20</option>
                    <option value="25">25</option>
                  </select>   <? echo $la_s_num_res2 ?>.</font></td>
              </tr>
            </tbody>
          </table>
        </td>
      </tr>

  </table>
</form></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td></td>
    <td></td>
    <td></td>
  </tr>
	<!--
  <tr>
    <td><? echo $la_advanced ?></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td>  <form action="search.php" method="post">
		<input type=hidden name=adv value=1>
  <table cellSpacing="0" border="0" width="100%">

       
      <tr>
        <td bgColor="#000000">
          <table cellSpacing="0" cellPadding="3" border="0" width="100%">
            <tbody>
              <tr>
                <td width="100%" bgColor="#EAEAEA"><font size="2"><input name="searchword" size="20" style="FONT-SIZE: 8pt" size="1"><input type="submit" value="Search" style="FONT-SIZE: 8pt" size="1">
                  <? echo $la_s_category ?>
                  
                  <?
                  	require("list_hovedkat.php");
                  ?>
                  
                    <? echo $la_find_ads ?> <input name="s_userid" size="20" style="FONT-SIZE: 8pt" size="1">
                  <? echo $la_find_ads2 ?> <input name="s_email" size="20" style="FONT-SIZE: 8pt" size="1">.</font></td>
              </tr>
            </tbody>
          </table>
        </td>
      </tr>

  </table>
</form></td>
    <td></td>
    <td></td>
  </tr> -->
</table>




<?
}
if ($searchword || $adv)
{	 
	 $kid=1;
	 
 	 require("links.php");
}

require("config/footer.inc.php");

?>