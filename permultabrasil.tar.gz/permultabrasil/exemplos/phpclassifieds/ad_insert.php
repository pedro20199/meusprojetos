<table><tr><td><?

if ($sitedescription AND $sitetitle AND $sitecatid)
{
 	if ($update_rq)
 	{
 		$sitetitle1 = strip_tags ("$sitetitle1");
 		$sitedescription1 = strip_tags ("$sitedescription1");
 		$custom_field_11 = strip_tags ("$custom_field_11");
 		$custom_field_21 = strip_tags ("$custom_field_21");
 		$custom_field_31 = strip_tags ("$custom_field_31");
 		$custom_field_41 = strip_tags ("$custom_field_41");
 		$custom_field_51 = strip_tags ("$custom_field_51");
 		$custom_field_61 = strip_tags ("$custom_field_61");
 		$custom_field_71 = strip_tags ("$custom_field_71");
 		$custom_field_81 = strip_tags ("$custom_field_81");
 		
 		
 		$sql_update = "update $ads_tbl set sitetitle='$sitetitle1',sitedate='$dagens_dato', expiredate='$expiredate', sitedescription='$sitedescription1',siteurl='$siteur',sitecatid=$sitecatid,sitehits='$sitehits',sitevotes='$sitevotes', custom_field_1='$custom_field_11', custom_field_2='$custom_field_21', custom_field_3='$custom_field_31', custom_field_4='$custom_field_41', custom_field_5='$custom_field_51', custom_field_6='$custom_field_61', custom_field_7='$custom_field_71', custom_field_8='$custom_field_81' where siteid = '$siteid'";
		$result = mysql_query ($sql_update);
		//print("$sql_update");
 	}
 	else
 	{
 		$sitetitle = strip_tags ("$sitetitle");
 		$sitedescription = strip_tags ("$sitedescription");
 		$custom_field_1 = strip_tags ("$custom_field_1");
 		$custom_field_2 = strip_tags ("$custom_field_2");
 		$custom_field_3 = strip_tags ("$custom_field_3");
 		$custom_field_4 = strip_tags ("$custom_field_4");
 		$custom_field_5 = strip_tags ("$custom_field_5");
 		$custom_field_6 = strip_tags ("$custom_field_6");
 		$custom_field_7 = strip_tags ("$custom_field_7");
 		$custom_field_8 = strip_tags ("$custom_field_8");
 	  
 	  
 	  $sql_insert = "insert into $ads_tbl
               (
                 sitetitle,
                 sitedescription,
                 siteurl,
                 sitedate,
                 expiredate,
                 sitecatid,
                 sitehits,
                 sitevotes,
                 sites_userid,
                 sites_pass,
                 custom_field_1,
                 custom_field_2,
                 custom_field_3,
                 custom_field_4,
                 custom_field_5,
                 custom_field_6,
                 custom_field_7,
                 custom_field_8)

                 values

                 (
                 '$sitetitle',
                 '$sitedescription',
                 '$siteurl',
                 '$dagens_dato',
                 '$expiredate',
                 '$sitecatid',
                 '$sitehits',
                 '$sitevotes',
                 '$userid',
                 '$pass',
                 '$custom_field_1',
                 '$custom_field_2',
                 '$custom_field_3',
                 '$custom_field_4',
                 '$custom_field_5',
                 '$custom_field_6',
                 '$custom_field_7',
                 '$custom_field_8')";
                 
		$result = mysql_query ($sql_insert);
		$adid = mysql_insert_id(); 
	     }

if($debug)
{
 		print("$sql_insert");
}

$status = $registered_site;

if ($siteid)
{
	$adid = $siteid;
}

if ($picture_upload_enable)
{

	 if ($fileimg_upload == 1)
	 {
 	 	$url_forward = "upload_file.php?pictures_siteid=$adid";
	 }
	 else
   	 {
    		$url_forward = "upload_new.php?pictures_siteid=$adid";
   	 }
	print("<font class='text'><b>Pictureupload?</b><br>You can now choose to upload a picture to your ad.<br>
	Choose:<p><a href='$url_forward'>I want to upload a picture</a> |  <a href='index.php'>I do not want picture</a><p>");
}            

require("config/config.inc.php");
$sendto = "$from_adress";
$from = "$from_adress";
$subject = "$admin_new_ad_subject";
$message = "$admin_new_ad";
$headers = "From: $from\r\n";
// send e-mail
mail($sendto, $subject, $message, $headers);

if ($auto == 1)
{
 require("update.php");
}


// if something goes wrong !
}
else
{
 		print("<ol>");
 		if (!$sitetitle)
		{
				print("<font class='text'><li><font color='red'>$la_error_msg1</font></li></font>");
		}
		
		if (!$sitedescription)
		{
		 	  print("<font class='text'><li><font color='red'>$la_error_msg2</font></li></font>");
		}
		
		if (!$sitecatid)
		{
		 	  print("<font class='text'><li><font color='red'>$la_error_msg3</font></li></font>");
		}
		
		print("</ol>");
				
				
				
				
		require("html_ad_ad.php");
}

?>
</td></tr></table>