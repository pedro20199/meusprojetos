<html>
<head>
<font face="arial" size="2">
<h3>Conditions/terms</h3>

<p>
<b>About security:</b><br>
This site is not Pentagon! Choose a password that you will not loose anyhing by other people see it. We will seek to keep your password private.
Other people might also see the password (if we screw up...). So, please choose a simple password, that is not used any other
place than here. 

<p>
<b>Email-mass mail:</b><br>
    If you do not want to be updated about news or important messages, please check ("I do not want important
    information" when register. We will then try to avoid send you email. 
    Please also bear in mind that you will also NOT be told if anything happens to your ad if you choose not
    to get this information.

<p>
<b>Responisble:</b><br>
We want to be a serious site, and do want everybody to be happy. Sometimes, it might happen
that problem occour. If this happens, we will try to fix, but anyway, we accept no
responibility. All adverticeing is on your own risk and profit.

    <p>
 <a href="javascript:window.close();">Close window</a>
</form>
</body>
</html>
