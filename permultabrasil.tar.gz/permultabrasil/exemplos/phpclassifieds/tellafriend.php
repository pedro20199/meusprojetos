<html
<head>

</head>

<body>
<h3><b><? echo $la_tell_a_friend ?></b></h3>
<?
require("config/config.inc.php");
if ($submit)
{
 	 
	 
	if ($avsender_epost AND $mottaker_epost)
	{	 		
				print("<p>$la_message_sent $mottaker_epost !</p>");
				$melding = strip_tags($kommentar);
				$sendto = $mottaker_epost;
				$from = $avsender_epost;
				$subject = "$la_message_subject";
				$message = "$avsender_epost $la_message_msg: \n
http://$url/detail.php?siteid=$id\n\n $la_message_comment:\n
------------\n$melding\n\n\n$la_sent_from: http://$url";

				$headers = "From: $from\r\n";
				// send e-mail
				mail($sendto, $subject, $message, $headers);
	}
	
	else
	{
	 		  print("<b>$la_tell_error</b>");
	}	
				
			
}
else
{

?>
<p><b><? echo $adtitle  ?> </b>(<? echo $id ?>)
<br><? echo $la_tell_welcome ?></p>
<form method="post" action="<?php echo $PHP_SELF?>"> 
<input type="hidden" name="id" value="<? echo $id ?>">
  <p> <u><? echo $la_reciever ?><br>
    </u> 
    <input type="text" name="mottaker_epost" size="20">
  </p>
  <p><u><? echo $la_sender ?><br>
    </u>
    <input type="text" name="avsender_epost" size="20">
  </p>
  <p><u><? echo $la_message_comment ?><br>
    </u>
    <textarea rows="2" name="kommentar" cols="40"></textarea>
    <br>
    <input type="submit" value="Send" name="submit">
  </p>
</form></p>
<?
}
?>
 <a href="javascript:window.close();"><? echo $la_close ?></a>
</body>
</html>
