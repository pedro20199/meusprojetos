<html>

<?
require ("config/config.inc.php");

$sql1 = "select * from $cat_tbl where allowads = 'on' order by catfullname";
$result1 = mysql_query ($sql1);

while ($row1 = mysql_fetch_array($result1)) 
{
 			$catid1 = $row1["catid"];
      $catfullname1 = $row1["catfullname"];
			$catfatherid1 = $row1["catfatherid"];
			$resultat = mysql_query ("select siteid from $ads_tbl where sitecatid = $catid1");
  		$antall = mysql_num_rows($resultat);
			$rad = mysql_fetch_array($resultat);
  			$siteid = $rad["siteid"];
			$this_root_total = $antall;
			$resultat = mysql_query ("update $cat_tbl set total = $this_root_total where siteid = $siteid");
			print "";
			$sql2 = "select * from $cat_tbl where catfatherid = $catid1 AND allowads = 'on' order by catfullname";
			$result2 = mysql_query ($sql2);
			while ($row2 = mysql_fetch_array($result2)) 
			{
 		 	 			$catid2 = $row2["catid"];
			 			$catfullname2 = $row2["catfullname"];
						print "<option value='$catid2'>$catfullname2</option>";
			
						$sql3 = "select * from $cat_tbl where catfatherid = $catid2 AND allowads = 'on' order by catfullname";
						$result3 = mysql_query ($sql3);
						while ($row3 = mysql_fetch_array($result3)) 
						{
			 			 			$catid3 = $row3["catid"];
									$catfullname3 = $row3["catfullname"];
																	$resultat = mysql_query ("select count(*) from $ads_tbl where sitecatid = $catid3");
  																	$rad = mysql_fetch_array($resultat);
  																	$ads = $rad["count(*)"];
																		print "$catfullname3 - $ads";
	
									
									$sql4 = "select * from $cat_tbl where catfatherid = $catid3 AND allowads = 'on' order by catfullname";
									$result4 = mysql_query ($sql4);
									while ($row4 = mysql_fetch_array($result4)) 
									{
			 					 			$catid4 = $row4["catid"];
											$catfullname4 = $row4["catfullname"];
											print "<option value='$catid4'>$catfullname4</option>";
								
								
											$sql5 = "select * from $cat_tbl where catfatherid = $catid4 AND allowads = 'on' order by catfullname";
											$result5 = mysql_query ($sql5);
											while ($row5 = mysql_fetch_array($result5)) 
											{
			 					 			 				$catid5 = $row5["catid"];
															$catfullname5 = $row5["catfullname"];
															print "<option value='$catid5'>$catfullname5</option>";
															
															$sql6 = "select * from $cat_tbl where catfatherid = $catid5 AND allowads = 'on' order by catfullname";
															$result6 = mysql_query ($sql6);
															while ($row6 = mysql_fetch_array($result6)) 
															{
			 					 			 				 			$catid6 = $row6["catid"];
																		$catfullname6 = $row6["catfullname"];
																		$resultat = mysql_query ("select count(*) from $ads_tbl where sitecatid = $catid6");
  																	$rad = mysql_fetch_array($resultat);
  																	$ads = $rad["count(*)"];
																		print "$catfullname6 - $ads";
															
																		$sql7 = "select * from $cat_tbl where catfatherid = $catid6 AND allowads = 'on' order by catfullname";
																		$result7 = mysql_query ($sql7);
															
																		while ($row7 = mysql_fetch_array($result7)) 
																		{
			 					 			 				 			 			$catid7 = $row7["catid"];
																					$catfullname7= $row7["catfullname"];
																					
																					$resultat = mysql_query ("select count(*) from $ads_tbl where sitecatid = $catid7");
  																				$rad = mysql_fetch_array($resultat);
  																				$ads = $rad["count(*)"];
																					print "$catfullname7 - $ads";
																						
																						
																		} // 7
															
															
															} // 6
																										
											
											} // 5
								
									 } // 4
								
								
							} // 3
	
	
			} // 2	
	

					
}

?>
</html>
