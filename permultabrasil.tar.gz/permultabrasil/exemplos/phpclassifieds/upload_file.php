<?
session_start();
require("config/header.inc.php");
require("config/config.inc.php");
require("functions.php");
if (!$special_mode)
{ print("$menu_ordinary<p>"); }
print("<h2>$name_of_site</h2>");
print "<table border='1' cellpadding='2' width='100%' bgcolor='#DDDDDD' bordercolordark='#FFFFFF'>";
print "<tr>";
print "<td><font face='Verdana' size='1'><b>Administration menu</b></font></td>";
print "<td>&nbsp;</td>";
print "<td align='right'><font face='Verdana' size='1'>Logged in as: $valid_user</font></td>";
print "</tr>";
print "<tr>";
print "<td><a href='member.php'><font face='Verdana' size='1'><b>Admin frontpage</b></font></a></td>";
print "<td><a href='change.php'><font face='Verdana' size='1'><b>$change_user</b></font></a></td>";
print "<td><a href='pass.php'><font face='Verdana' size='1'><b>Change password</b></font></a></td>";
print "</tr>";
print "</table>";
check_valid_user();
?>

<table width=100%><td><tr>

<?php if ($HTTP_POST_VARS['action']) 
{ 
 ?> 
 <b>File Upload Results</b><BR><BR> 
 <?php 
     
 $uploadpath = "$full_path_to_public_program" . "/images/"; 
 $source = $HTTP_POST_FILES['file1']['tmp_name']; 
 $dest = "$full_path_to_public_program" . "/images/"; 

 if ( ($source != 'none') && ($source != '' )) 
 { 
 	$imagesize = getimagesize($source); 
	switch ( $imagesize[2] ) { 

        case 0: 
	  echo '<BR> Image is unknown <BR>';  break; 
        case 1: 
          echo '<BR> Image is a GIF <BR>'; 
          $idnr = uniqid('img').'.gif';
          $dest = $uploadpath.$idnr;
	  $filename = $idnr;  
          break; 
        case 2: 
	  echo '<BR> Image is a JPG <BR>'; 
	  $idnr = uniqid('img').'.jpg';
          $dest = $uploadpath.$idnr;
	  $filename = $idnr;  
          break;         
	case 3: 
	  echo '<BR> Image is a PNG <BR>'; 
	  $idnr = uniqid('img').'.png';
          $dest = $uploadpath.$idnr;
	  $filename = $idnr;  
 } 

 if ( $dest != '' ) 
 { 
	if ( move_uploaded_file( $source, $dest ) ) 
	{
		print "File successfully stored<br>";
    print "<a href='index.php'>Return to frontpage</a><br>";
		print "<a href='member.php'>Add Another ad</a><br>";
		$result1=MYSQL_QUERY("UPDATE $ads_tbl set img_stored = '$filename' where siteid=$pictures_siteid");
		print("<img src='images/$filename'>"); 
		$new_image_place = $dest;
		chmod ("$new_image_place", 0666);
	} 
	else
	{ 
               echo 'File could not be stored.<BR>'; 
	} 

 }  

} 
else
{ 
	echo 'File not supplied, or file too big.<BR>'; 
} 

?> 
<BR><A HREF="<?php echo $PHP_SELF ?>">Upload again</A> | <A HREF="index.php">Go to Frontpage</A>

<?php } else { ?> 

<?php if ($HTTP_POST_VARS['action']) { ?> 
?> 
<BR><A HREF="index.php">Return to Frontpage</A> 

<?php } else { ?> 
<h2>Picture Upload</h2>
<? echo $upload_picture_text; ?>

<FORM METHOD="POST" ENCTYPE="multipart/form-data" ACTION="<?php echo $PHP_SELF;?>"> 
<INPUT TYPE="hidden" name="pictures_siteid" value="<? echo $pictures_siteid ?>">
<INPUT TYPE="HIDDEN" NAME="MAX_FILE_SIZE" VALUE="800000"> 
<INPUT TYPE="HIDDEN" NAME="action" VALUE="1"> 
File 1: <INPUT TYPE="FILE" NAME="file1" SIZE="30"><BR><BR> 
<INPUT TYPE="SUBMIT" VALUE="Upload"> 
</FORM> 

<?php } ?> 
<?php } 

print("</tr></td></table>");
require("config/footer.inc.php");
?>



