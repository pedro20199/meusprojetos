<html>
<head>
</head>

<body>
<h2>PHP CLASSIFIEDS INSTALL</h2>
<a href="install.php">0</a>&nbsp;|&nbsp;<a href="install.php?level=1">1</a>&nbsp;|&nbsp;<a href="install.php?level=2">2</a>&nbsp;|&nbsp;<a href="install.php?level=3">3</a>&nbsp;|&nbsp;<a href="install.php?level=4">4</a>&nbsp;|&nbsp;<a href="install.php?level=5">5</a><br>
<? 
if (!$level)
{
	print("<p>Step 1&nbsp; &gt;&gt; Step 2&nbsp; &gt;&gt; Step 3&nbsp; &gt;&gt; Step
4&nbsp; &gt;&gt; Step 5</p>");
}
if ($level == 1)
{
	print("<p><b>Step 1</b>&nbsp; &gt;&gt; Step 2&nbsp; &gt;&gt; Step 3&nbsp; &gt;&gt; Step
4&nbsp; &gt;&gt; Step 5</p>");
}
if ($level == 2)
{
	print("<p>Step 1&nbsp; &gt;&gt; <b>Step 2</b>&nbsp; &gt;&gt; Step 3&nbsp; &gt;&gt; Step
4&nbsp; &gt;&gt; Step 5</p>");
}
if ($level == 3)
{
	print("<p>Step 1&nbsp; &gt;&gt; Step 2&nbsp; &gt;&gt; <b>Step 3</b>&nbsp; &gt;&gt; Step
4&nbsp; &gt;&gt; Step 5</p>");
}
if ($level == 4)
{
	print("<p>Step 1&nbsp; &gt;&gt; Step 2&nbsp; &gt;&gt; Step 3&nbsp; &gt;&gt; <b>Step
4</b>&nbsp; &gt;&gt; Step 5</p>");
}
if ($level == 5)
{
	print("<p>Step 1&nbsp; &gt;&gt; Step 2&nbsp; &gt;&gt; Step 3&nbsp; &gt;&gt; Step
4&nbsp; &gt;&gt; <b>Step 5</b></p>");
}

 ?>

</p>
<table width="70%">
<tr>
<td>
<?

// NOTE: Here you can set full path to you files if the in-built php function
// getcwd doesn�t work.
// Example: $dir = "/home/user/public_html/phpclassifieds";
// Remember to remove! the $dir = getcwd(); if you do this.

// Uncomment (remove // ) from THE BELOW LINE if manually set:
// $dir = "/home/user/public_html/phpclassifieds"; 

// Delete BELOW LINE if manually set $dir above ! ! !
$dir = getcwd ();

if (!$dir)
{
	$dir = dirname($SCRIPT_FILENAME); 
}



$configdir = $dir . "/config";
$configdir_perm = fileperms("$configdir");

$imagedir = $dir . "/images";
$imgedir_perm = fileperms("$imagedir");

$wapdir = $dir . "/wap";
$wapdir_perm = fileperms("$wapdir");

$admindir = $dir . "/admin";
$admindir_perm = fileperms("$admindir");

print("<p>");



if ($level == "") 
{
 ?>
<p>Welcome to PHP Classifieds install. This install program will take you through all you have to do to get PHP Classifieds up and running. NOTE: Make sure that you run this installer (with all files) in the same folder as you wish to install the program into.</p>
<p>
<textarea rows="5" name="S1" cols="70">This program is only free for NON-COMMERCIAL or NON-PROFIT use. All use of this program is under strict licence. If you do not agree, do not use this program.  I (Are Haugsdal email: are@a4.no), or my company (Haugsdal Webtjenester), or any other person related in/to this program accepts NO liability or claims whatsoever. Some few examples of these liabilities/claims: Damages in any way to people, property, machines, working hours, repair work or any other costs releated to this program in any matter. 

ALL USE OF THIS PROGRAM IS ON YOUR OWN RISK AND COSTS. This program is not programmed to be 100% secure, and therefore can not be used in life critical environments, or heavy critical e-commerce (mission-critical) envirionments that will loose from hundreds of dollar to millions of dollar of small coding errors. (Anyway, Haugsdal Webtjenester/Are Haugsdal accept no liabilities).

In order to use this program at your website, and your company belong to a profit-company or a commercial company, you will neeed to pay yhe license. It does not help if you let users post ads for free, you are still making profit if your company gain econmomic profit or advantage of its use, either as traffic-increase, or as direct ad sale. Only NON-PROFITT whatsoever can use this program completely free, without support. Example of non-profit org is churches, humain-aid corparations and private persons that do not have ads on their domain, and lets user register for free.

Any claim, or disputes shall be governed by the laws and courts in Norway. 

Also, this program is not allowed for use in Norway (websites that offer their sercvises or adverticeing in PHP Classifieds to Norwegian users) due to competition considerations. Exception can be made by written aknowledge from the author of this program, Are Haugsdal. 

You may not reproduce and/or (re)sell the hole program, or any part of our code without the written aknowledge from the author of this program, Are Haugsdal. All code is copyright 2001 Haugsdal Webtjenester.</textarea><br>
If you want to pay by Visa, or Mastercard or Check, visit <a href="http://www.deltascripts.com/phpclassifieds/"> our website</a> to pay the licence</a>. 
</p>	 
<p>
<h3>Error-checking:</h3>
<?
if ($dir) { print("<b>$dir</b> is reported to be your full install-path."); }
else { print("<font color=red>Please fix</font>: <small><br>There seems to be an error, because php4 doesn�t report your full path.</small><br>"); }
print("<br>");
if (file_exists("admin/setconfig.php")) { } else { print("<font color=red>Please fix</font>: Couldn�t locate setconfig.php ($dir)<small><br></small><br>"); }
if ($configdir_perm == 16895) { print("<b>$configdir</b> is <font color=green>correctly set to CHMOD 777</font><br>"); }
else { print("<font color=red>Please fix</font>: <small><br>You must set the directory <i>$configdir</i> to all writeable (chmod 777 $file).</small><br>"); }
if ($imgedir_perm == 16895) { print("<b>$imagedir</b> is <font color=green>correctly set to CHMOD 777</font><br>"); }
else { print("<font color=red>Please fix</font>: <small><br>You must set the directory <i>$imagedir</i> to all writeable (chmod 777 $file). </small><br>"); }	  
if ($admindir_perm==16895) { print("<b>$admindir</b> is <font color=green>correctly set to CHMOD 777</font><br>"); }
else { print("<font color=red>Please fix</font>: <small><br>You must set the directory <i>$admindir</i> to all writeable (chmod 777 $file). </small><br>"); }	  
if ($wapdir_perm == 16895) { print("<b>$wapdir</b> is <font color=green>correctly set to CHMOD 777</font><br>"); }
else { print("<font color=red>Please fix</font>: <small><br>You must set the directory <i>$wapdir</i> to all writeable (chmod 777 $file). </small><br>"); }	  


print("<p><p>If you didn�t recieve any errors above, click below:<p>");

print("<a href='install.php?level=1'>I agree to the conditions, START INSTALL</a>");
}
if ($level == "1")
{
	 ?>
	 	 </p>
 	 <form method="POST" action="install.php">
	 <input type="hidden" name="level" value="1">
	  <b>DATABASE INFO</b><br>In order to use PHP CLASSIFIEDS, you must have access to a MySql database, and you must have created a database where the below user will have access. This info must be correct. The DB.PHP file will be installed in <b><?  print("$admindir"); ?></b>.<p>
<table>
<tr><td>Hostname (often localhost) :</td><td><input type="text" name="hostname" size="20"></td></tr>

<tr><td>DB Username : </td><td><input type="text" name="db_username" size="20"></td></tr>
<tr><td>DB Password : </td><td><input type="text" name="db_password" size="20"></td></tr>
<tr><td>Databasename: </td><td><input type="text" name="db_name" size="20"></td></tr></table>
<input type="submit" value="Create databasefile" name="submit">
 	 </form>

	 
	 <?
	 
	 
	 
	 
	 if ($submit)
	 {
	 		
			if (file_exists("$admindir/db.php"))
			{
			 	 	 unlink ("$admindir/db.php");
			}
			
								
		
	 
		 		 $fd = fopen( "$admindir/db.php", "w+" );
				  		  
$str_gen = "<? mysql_connect (\"$hostname\",\"$db_username\",\"$db_password\");\nmysql_select_db (\"$db_name\");\n
\$datab='$db_name';\n
\$dbusr='$db_username';\n
\$dbpass='$db_password';\n
\$dbhost='$hostname';\n
?>";				 
				 $len_gen = strlen( $str_gen );
				 fwrite( $fd, $str_gen, $len_gen );
			
		 		 fclose( $fd );
							 
				 print("Writed db.php to $admindir/db.php.");
				 print("<a href='install.php?level=2'>Go on to level 2</a>");
				 

		}

}

// -------------------- Step 2	Create db file, set initial tables and fill the config table	------------------
if ($level == "2")
{
 	 
 	 
 	 ?>
	 
	 <form method="POST" action="install.php">
	 <input type="hidden" name="level" value="2">	 	 
	 <b>TABLE CREATION</b><p>
	 
	<? require("$dir/admin/db.php"); ?>
	 Note: Config table that the program will create, can not be changed. If you already have a table called Config in MySql, this must be deleted by you manually in order to continue install. Be sure to fill out ALL FIELDS below, else the installer will fail.<p>
	 
	 <?
	 if (!$submit)
	 {
	 ?>
	 <table>
	 <tr>
	 	<td><font class='text'><b>Category table</b><br>MySql field where PHP Classifieds will store its categories.</font><br>
		<input type="text" size="10" maxlength="10" name="cat_tbl" value="<?php echo $cat_tbl ?>"><p></td>
	 </tr>

	 <tr>
	 		<td><font class='text'><b>Ads table</b><br>Ad table where all your ads is saved.</font><br>
			<input type="text" size="10" maxlength="10" name="ads_tbl" value="<?php echo $ads_tbl ?>"><p>
			</td>
	</tr>

	<tr>
			<td><font class='text'><b>User table</b><br>MySql field where PHP Classifieds will store its users.</font><br>
			<input type="text" size="10" maxlength="10" name="usr_tbl" value="<?php echo $usr_tbl ?>"><p>
			</td>
	</tr>
	
		<tr>
			<td><font class='text'><b>Picture table</b><br>MySql field where PHP Classifieds will store its images.</font><br>
			<input type="text" size="10" maxlength="10" name="pic_tbl" value="<?php echo $pic_tbl ?>"><p>
			</td>
	</tr>
	
	
	
	</table>
	<input type="submit" value="Create tables" name="submit"></form>

	 <?
	 }
	 if ($submit AND $level==2)
	 {
	 
$result1 = mysql_query("CREATE TABLE $cat_tbl(
catid int(11) DEFAULT '0' NOT NULL auto_increment,
   catfatherid int(11),
   catname varchar(100),
   catdescription varchar(150),
   catimage varchar(100) DEFAULT 'default.gif',
   total varchar(5) DEFAULT '0',
   latest_date varchar(8),
   cattpl varchar(50),
   allowads char(2),
   catfullname varchar(150),
   PRIMARY KEY (catid)
   )");

$result2 = mysql_query("CREATE TABLE $ads_tbl (
siteid int(11) DEFAULT '0' NOT NULL auto_increment,
   sitetitle varchar(100),
   sitedescription text,
   siteurl varchar(100),
   sitedate varchar(10),
   expiredate varchar(12),
   sitecatid int(11),
   sitehits int(11),
   sitevotes double(16,4),
   sites_userid int(11),
   sites_pass varchar(12),
   custom_field_1 varchar(50),
   custom_field_2 varchar(50),
   custom_field_3 varchar(50),
   custom_field_4 varchar(50),
   custom_field_5 varchar(50),
   custom_field_6 varchar(50),
   custom_field_7 varchar(50),
   custom_field_8 varchar(50),
   picture int(11) DEFAULT '0',
   img_stored varchar(70),
   datestamp timestamp(8),
   PRIMARY KEY (siteid))"); 

$result3 = mysql_query("CREATE TABLE $usr_tbl (
userid int(11) DEFAULT '0' NOT NULL auto_increment,
   name varchar(100),
   adressfield1 varchar(100),
   adressfield2 varchar(100),
   adressfield3 varchar(100),
   phone varchar(30),
   email varchar(30),
   pass varchar(12),
   registered timestamp(8),
   emelding tinyint(4),
   num_ads int(11) DEFAULT '0',
   country varchar(50),
   hide_email tinyint(4),
   custom_1 varchar(50),
   PRIMARY KEY (userid)
)");

$result4 = mysql_query("CREATE TABLE $pic_tbl (
id int(4) DEFAULT '0' NOT NULL auto_increment,
   pictures_siteid varchar(6),
   bin_data longblob,
   filename varchar(50),
   filesize varchar(50),
   filetype varchar(50),
   PRIMARY KEY (id)
)");

$result5 = mysql_query("CREATE TABLE Config (
id tinyint(1) DEFAULT '0' NOT NULL,
   version varchar(10),
   language varchar(10) DEFAULT 'eng.php' NOT NULL,
   urladress varchar(100),
   full_path varchar(100),
   from_adress varchar(50) NOT NULL,
   advanced_delete tinyint(4) DEFAULT '1',
   auto tinyint(4) DEFAULT '1',
   delete_members tinyint(4) DEFAULT '0',
   cat_per_c tinyint(4) DEFAULT '5' NOT NULL,
   expire_after tinyint(4) DEFAULT '20' NOT NULL,
   latest tinyint(4) DEFAULT '0',
   upload tinyint(4) DEFAULT '1' NOT NULL,
   fileupload tinyint(4) DEFAULT '0',
   cat_tbl varchar(10) DEFAULT 'Categories' NOT NULL,
   ads_tbl varchar(10) DEFAULT 'Ads' NOT NULL,
   usr_tbl varchar(10) DEFAULT 'Pictures' NOT NULL,
   pic_tbl varchar(10) DEFAULT 'Pictures' NOT NULL,
   c1 varchar(15) DEFAULT 'Price',
   c2 varchar(15),
   c3 varchar(15),
   c4 varchar(15),
   c5 varchar(15),
   c6 varchar(15),
   c7 varchar(15),
   c8 varchar(15),
   simple tinyint(4),
   piclimit varchar(7) DEFAULT '47000',
   numads tinyint(4),
   email_act tinyint(4),
   spec tinyint(4),
   header_file text,
   footer_file text,
   name_of_site varchar(60),
   PRIMARY KEY (id)
	 )");
	 
sleep(1);

$result6 = mysql_query("INSERT INTO Config VALUES ( '1', '6.03', 'eng.php', 'www.domain/classifieds', '', 'webmaster@yourdomain.com', '1', '1', '1', '6', '20', '0', '1', '0', '$cat_tbl', '$ads_tbl', '$usr_tbl', '$pic_tbl', '', '', '', '', '', '', '', '', '0', '47000', '20', '0', '0', '<html>
<head>
<link rel=stylesheet href=\"style.css\" type=\"text/css\">', '<!-- Start searchengine-->    

<form action=\"search.php\" method=\"post\">
  <table cellSpacing=\"0\" border=\"0\" width=\"100%\">
    <tbody>
      <tr>
        <td>
           
          <? include(\"\$full_path_to_public_program/tell.php\"); ?> <font color=\"#C0C0C0\">We have total <? echo \$antall ?> users, and <? echo \$annonser
          ?> ads. Also we have given <? echo \$detaljvisninger ?> detailed views of ads.</font>
        </td>
      </tr>
      <tr>
        <td bgColor=\"#000000\">
          <table cellSpacing=\"0\" cellPadding=\"3\" border=\"0\" width=\"100%\">
            <tbody>
              <tr>
                <td width=\"100%\" bgColor=\"#EAEAEA\"><font size=\"2\"><input name=\"searchword\" size=\"20\" style=\"FONT-SIZE: 8pt\" size=\"1\"><input type=\"submit\" value=\"Search\" style=\"FONT-SIZE: 8pt\" size=\"1\">
                  in category 
                  
                  <?
                  	include(\"list_hovedkat.php\");
                  ?>
                  
                    and show <select style=\"FONT-SIZE: 8pt\" size=\"1\" name=\"limit\">
                    <option value=\"10\" selected>10</option>
                    <option value=\"15\">15</option>
                    <option value=\"20\">20</option>
                    <option value=\"25\">25</option>
                  </select>   results on page.</font></td>
              </tr>
            </tbody>
          </table>
        </td>
      </tr>
    </tbody>
  </table>
</form>

<!-- In freeware, noncommercial version, you must keep a link back to us at http://www.deltascripts.com/phpclassifieds/. --> 
<font class=\'text\'>Powered by <a href=\"http://www.deltascripts.com/phpclassifieds/\">PHP Classifieds</a> <? echo \$v ?>.</font>
<!-- // End search-->   

</body>
</html>
','PHP Classifieds')");

$result1 = mysql_query("ALTER TABLE $ads_tbl 
ADD f1 VARCHAR (50) ,
ADD f2 VARCHAR (50) ,
ADD f3 VARCHAR (50) ,
ADD f4 VARCHAR (50) ,
ADD f5 VARCHAR (50) ,
ADD f6 VARCHAR (50) ,
ADD f7 VARCHAR (50) ,
ADD f8 VARCHAR (50) ,
ADD f9 VARCHAR (50) ,
ADD f10 VARCHAR (50) ,
ADD f11 VARCHAR (50) ,
ADD f12 VARCHAR (50) ,
ADD f13 VARCHAR (50) ,
ADD f14 VARCHAR (50) ,
ADD f15 VARCHAR (50)");
// End of ALTER

$result2 = mysql_query("CREATE TABLE template (
   tplid int(11) NOT NULL auto_increment,
   name varchar(50),
   f1_caption varchar(50),
   f1_type varchar(50),
   f1_mandatory char(3),
   f1_length varchar(5),
   f1_filename varchar(50),
   f2_caption varchar(50),
   f2_type varchar(50),
   f2_mandatory char(3),
   f2_length varchar(5),
   f2_filename varchar(50),
   f3_caption varchar(50),
   f3_type varchar(50),
   f3_mandatory char(3),
   f3_length varchar(5),
   f3_filename varchar(50),
   f4_caption varchar(50),
   f4_type varchar(50),
   f4_mandatory char(3),
   f4_length varchar(5),
   f4_filename varchar(50),
   f5_caption varchar(50),
   f5_type varchar(50),
   f5_mandatory char(3),
   f5_length varchar(5),
   f5_filename varchar(50),
   f6_caption varchar(50),
   f6_type varchar(50),
   f6_mandatory char(3),
   f6_length varchar(5),
   f6_filename varchar(50),
   f7_caption varchar(50),
   f7_type varchar(50),
   f7_mandatory char(3),
   f7_length varchar(5),
   f7_filename varchar(50),
   f8_caption varchar(50),
   f8_type varchar(50),
   f8_mandatory char(3),
   f8_length varchar(5),
   f8_filename varchar(50),
   f9_caption varchar(50),
   f9_type varchar(50),
   f9_mandatory char(3),
   f9_length varchar(5),
   f9_filename varchar(50),
   f10_caption varchar(50),
   f10_type varchar(50),
   f10_mandatory char(3),
   f10_length varchar(5),
   f10_filename varchar(50),
   f11_caption varchar(50),
   f11_type varchar(50),
   f11_mandatory char(3),
   f11_length varchar(5),
   f11_filename varchar(50),
   f12_caption varchar(50),
   f12_type varchar(50),
   f12_mandatory char(3),
   f12_length varchar(5),
   f12_filename varchar(50),
   f13_caption varchar(50),
   f13_type varchar(50),
   f13_mandatory char(3),
   f13_length varchar(5),
   f13_filename varchar(50),
   f14_caption varchar(50),
   f14_type varchar(50),
   f14_mandatory char(3),
   f14_length varchar(5),
   f14_filename varchar(50),
   f15_caption varchar(50),
   f15_type varchar(50),
   f15_mandatory char(3),
   f15_length varchar(5),
   f15_filename varchar(50),
   PRIMARY KEY (tplid));"); 
// End of result2

$result3 = mysql_query("INSERT INTO template (tplid, name, f1_caption, f1_type, f1_mandatory, f1_length, f2_caption, f2_type, f2_mandatory, f2_length, f3_caption, f3_type, f3_mandatory, f3_length, f4_caption, f4_type, f4_mandatory, f4_length, f5_caption, f5_type, f5_mandatory, f5_length, f6_caption, f6_type, f6_mandatory, f6_length, f7_caption, f7_type, f7_mandatory, f7_length, f8_caption, f8_type, f8_mandatory, f8_length, f9_caption, f9_type, f9_mandatory, f9_length, f10_caption, f10_type, f10_mandatory, f10_length, f11_caption, f11_type, f11_mandatory, f11_length, f12_caption, f12_type, f12_mandatory, f12_length, f13_caption, f13_type, f13_mandatory, f13_length, f14_caption, f14_type, f14_mandatory, f14_length, f15_caption, f15_type, f15_mandatory, f15_length) VALUES ('', '-', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '') ");
// End of result3

$result4 = mysql_query("ALTER TABLE $usr_tbl ADD usr_1 VARCHAR (150) , ADD usr_2 VARCHAR (150) , ADD usr_3 VARCHAR (150) , ADD usr_4 VARCHAR (150) , ADD usr_5 VARCHAR (150)"); 
// End of result 4 


$result5 = mysql_query("ALTER TABLE $usr_tbl CHANGE userid userid INT (11) not null");
$result6 = mysql_query("ALTER TABLE $usr_tbl DROP PRIMARY KEY");
$result7 = mysql_query("ALTER TABLE $ads_tbl ADD ad_username CHAR (50)"); 
$result8 = mysql_query("ALTER TABLE $usr_tbl CHANGE email email CHAR (50) not null");
$result9 = mysql_query("ALTER TABLE $usr_tbl DROP PRIMARY KEY, ADD PRIMARY KEY(email)");
$result10 =mysql_query("ALTER TABLE $cat_tbl ADD cattpl varchar(50), ADD allowads char(2), ADD catfullname varchar(150)"); 
$result11 = mysql_query("ALTER TABLE $usr_tbl ADD password_enc CHAR (30)"); 
$result11 = mysql_query("ALTER TABLE Config ADD usr_1_text VARCHAR (40) , ADD usr_2_text VARCHAR (40) , ADD usr_3_text VARCHAR (40) , ADD usr_4_text VARCHAR (40) , ADD usr_5_text VARCHAR (40)"); 
	 
	if ($result1 & $result2 & $result3 & $result4 & $result5 & $result6)
	{
 	 	 print("<p>Tables created, and all is OK.<p><a href='install.php?level=3'>Next step</a>.");

 	}
	else
	{
 		print("<font color=red>Table creation failed. Maybe tables already exists ?</font>");
	}
 }
// End of level 2...
}


// -------------------- Step 3	Set initial setup for PHP Classifieds	------------------
if ($level == "3")
{
	
	$setup = 1;	
	//require("admin/setconfig.php"); 
if (!$submit)
{
	?>

	
	<form method="post" action"<? echo $PHP_SELF ?>">
	<input type="hidden" name="level" value="3">

	<table>
	<tr>
	<td><b>FULL PATH</b><br>The program needs to know the full path to the phpclassifieds main dir. Below is the scripts suggestion, you might change the <i>classifieds</i> to something else.
	NOTE: This is one of the most important settings in the program. If this is set wrong, you will get errors over the hole program. Normally, the path is like /home/username/public_html/classifieds. The default path is set below, and <b>should</b> be the correct path !
	 Give the path without trailing slash (/).
	 <p>
	 Remember to go into admin area afterwards, to set your emailaddress and sitename before
	 you use the program.<p>
	 <br>
		<input type="text" size="50" maxlength="140" name="full_path" value="<?php echo $dir ?>">
<p>
	</td>
</tr></table>
<input type="submit" class="tekstfelt" name="submit" value="Save">
</form>

<?	
}
	
	if ($submit)
	{
	 	 $file_name = "$full_path/config/config.inc.php";
		 $file_pointer = fopen($file_name, "w"); 

		 fwrite($file_pointer,"<? /*PHP CLASSIFIEDS\n
		 NOTE: This file is generated automatically from admin ! DO NOT EDIT*/\n
		 \$version=\"6.03\";\r
		 \$full_path_to_public_program = \"$full_path\";\r
		 require(\"$full_path/language/eng.php\");\r
		 require(\"$full_path/admin/db.php\");\r ?>");
		 fclose($file_pointer); 
		 
		 	include("admin/db.php");
			$sql_update = "update Config set language='eng.php',full_path='$full_path' where id = 1";
			$result = mysql_query ($sql_update);
	
	 		print "<p><b>Path saved</b>";
	 		print "<br>You may continue to <a href='install.php?level=4'>next step</a>.";
		 
	}

	
	
	
	
}


// -------------------- Step 4	Password protecttion of admin dir	------------------
if ($level == "4")
{ 
	require("config/config.inc.php"); 
	require("admin/db.php"); 
/*
$result1 = mysql_query("ALTER TABLE $ads_tbl 
ADD f1 VARCHAR (50) ,
ADD f2 VARCHAR (50) ,
ADD f3 VARCHAR (50) ,
ADD f4 VARCHAR (50) ,
ADD f5 VARCHAR (50) ,
ADD f6 VARCHAR (50) ,
ADD f7 VARCHAR (50) ,
ADD f8 VARCHAR (50) ,
ADD f9 VARCHAR (50) ,
ADD f10 VARCHAR (50) ,
ADD f11 VARCHAR (50) ,
ADD f12 VARCHAR (50) ,
ADD f13 VARCHAR (50) ,
ADD f14 VARCHAR (50) ,
ADD f15 VARCHAR (50)");
// End of ALTER

$result2 = mysql_query("CREATE TABLE template (
   tplid int(11) NOT NULL auto_increment,
   name varchar(50),
   f1_caption varchar(50),
   f1_type varchar(50),
   f1_mandatory char(3),
   f1_length varchar(5),
   f1_filename varchar(50),
   f2_caption varchar(50),
   f2_type varchar(50),
   f2_mandatory char(3),
   f2_length varchar(5),
   f2_filename varchar(50),
   f3_caption varchar(50),
   f3_type varchar(50),
   f3_mandatory char(3),
   f3_length varchar(5),
   f3_filename varchar(50),
   f4_caption varchar(50),
   f4_type varchar(50),
   f4_mandatory char(3),
   f4_length varchar(5),
   f4_filename varchar(50),
   f5_caption varchar(50),
   f5_type varchar(50),
   f5_mandatory char(3),
   f5_length varchar(5),
   f5_filename varchar(50),
   f6_caption varchar(50),
   f6_type varchar(50),
   f6_mandatory char(3),
   f6_length varchar(5),
   f6_filename varchar(50),
   f7_caption varchar(50),
   f7_type varchar(50),
   f7_mandatory char(3),
   f7_length varchar(5),
   f7_filename varchar(50),
   f8_caption varchar(50),
   f8_type varchar(50),
   f8_mandatory char(3),
   f8_length varchar(5),
   f8_filename varchar(50),
   f9_caption varchar(50),
   f9_type varchar(50),
   f9_mandatory char(3),
   f9_length varchar(5),
   f9_filename varchar(50),
   f10_caption varchar(50),
   f10_type varchar(50),
   f10_mandatory char(3),
   f10_length varchar(5),
   f10_filename varchar(50),
   f11_caption varchar(50),
   f11_type varchar(50),
   f11_mandatory char(3),
   f11_length varchar(5),
   f11_filename varchar(50),
   f12_caption varchar(50),
   f12_type varchar(50),
   f12_mandatory char(3),
   f12_length varchar(5),
   f12_filename varchar(50),
   f13_caption varchar(50),
   f13_type varchar(50),
   f13_mandatory char(3),
   f13_length varchar(5),
   f13_filename varchar(50),
   f14_caption varchar(50),
   f14_type varchar(50),
   f14_mandatory char(3),
   f14_length varchar(5),
   f14_filename varchar(50),
   f15_caption varchar(50),
   f15_type varchar(50),
   f15_mandatory char(3),
   f15_length varchar(5),
   f15_filename varchar(50),
   PRIMARY KEY (tplid));"); 
// End of result2

$result3 = mysql_query("INSERT INTO template (tplid, name, f1_caption, f1_type, f1_mandatory, f1_length, f2_caption, f2_type, f2_mandatory, f2_length, f3_caption, f3_type, f3_mandatory, f3_length, f4_caption, f4_type, f4_mandatory, f4_length, f5_caption, f5_type, f5_mandatory, f5_length, f6_caption, f6_type, f6_mandatory, f6_length, f7_caption, f7_type, f7_mandatory, f7_length, f8_caption, f8_type, f8_mandatory, f8_length, f9_caption, f9_type, f9_mandatory, f9_length, f10_caption, f10_type, f10_mandatory, f10_length, f11_caption, f11_type, f11_mandatory, f11_length, f12_caption, f12_type, f12_mandatory, f12_length, f13_caption, f13_type, f13_mandatory, f13_length, f14_caption, f14_type, f14_mandatory, f14_length, f15_caption, f15_type, f15_mandatory, f15_length) VALUES ('', '-', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '') ");
// End of result3

$result4 = mysql_query("ALTER TABLE $usr_tbl ADD usr_1 VARCHAR (150) , ADD usr_2 VARCHAR (150) , ADD usr_3 VARCHAR (150) , ADD usr_4 VARCHAR (150) , ADD usr_5 VARCHAR (150)"); 
// End of result 4 


$result5 = mysql_query("ALTER TABLE $usr_tbl CHANGE userid userid INT (11) not null");
$result6 = mysql_query("ALTER TABLE $usr_tbl DROP PRIMARY KEY");
$result7 = mysql_query("ALTER TABLE $ads_tbl ADD ad_username CHAR (50)"); 
$result8 = mysql_query("ALTER TABLE $usr_tbl CHANGE email email CHAR (50) not null");
$result9 = mysql_query("ALTER TABLE $usr_tbl DROP PRIMARY KEY, ADD PRIMARY KEY(email)");
$result10 =mysql_query("ALTER TABLE $cat_tbl ADD cattpl varchar(50), ADD allowads char(2), ADD catfullname varchar(150)"); 
$result11 = mysql_query("ALTER TABLE $usr_tbl ADD password_enc CHAR (30)"); 
$result11 = mysql_query("ALTER TABLE Config ADD usr_1_text VARCHAR (40) , ADD usr_2_text VARCHAR (40) , ADD usr_3_text VARCHAR (40) , ADD usr_4_text VARCHAR (40) , ADD usr_5_text VARCHAR (40)"); 

*/  
	?>
	 <p><b>PASSWORD PROTECTION</b>
	 <br>You can now password protect your admin directory. By pushing the submit button,
	 .htaccess and .htpasswd file in the admin dir will be deleted, and recreated with
	 information given below. .htaccess is a file that will protect the dir with relatively high protection, and will give you a password promt when accessing the admin dir.</p>
	<p>
	<i>IMPORTANT: On Unix/Linux systems this type of protection will often be availble, but on Windows
	system, other methods of protection of the admin dir may be needed instead. Talk with your
	webhost if you are unsure about this, but always test if you have to supply correct
	username and password.</i> 
	</p>
	<p>
	Your .htaccess and .htpasswd files will be created in <b><? print("$admindir"); ?></b>.</p>


	 
	 <?
	 		if (file_exists("$admindir/.htaccess"))
			{
			 	 	$filemodtime = filemtime ("$admindir/.htaccess");
					$last_mod_hta = date("d.m.Y - H:i:s", $filemodtime); 
					print("Your existing htaccess file was last modified $last_mod_hta<br>");
					 
			}
			else
			{
			 		print("Good, No .htaccess file exists. <br>");
			}
			if (file_exists("$admindir/.htpasswd"))
			{
			 	   	$filemodtime = filemtime ("$admindir/.htpasswd");
					$last_mod_htp = date("d.m.Y - H:i:s", $filemodtime); 
					print("Your existing htpasswd file was last modified $last_mod_htp<br>");
			}
			
			else
			{
			 		print("Good, No .htpasswd file exists.");
			}
	 

	 ?>
</p><p></p>

		<form method="POST" action="install.php">
		<input type="hidden" name="level" value="4">
		<p align="center">Username : <input type="text" name="username" size="20"></p>
		<p align="center">Password : <input type="text" name="password" size="20"></p>
		<p align="center"><input type="submit" value="Create passwordprotection" name="submit"></p>
 	 	</form>
 <?
	 
	 
	 
	 
	 if ($submit)
	 {
	 		
			 
			
	 		
	 		
			if (file_exists("$admindir/.htaccess"))
			{
			 	 	 unlink ("$admindir/.htaccess");
			}
			
			if (file_exists("$admindir/.htpasswd"))
			{
			 	   unlink ("$admindir/.htpasswd");
			}
			

			
			
			if ($username AND $password)
	 		{ 
		 		 $usernamenew = $username;
		 		 $passwordnew = crypt ($password);
		 
		 		 $fd = fopen( "$admindir/.htaccess", "w+" );
 		 		 $fd2 = fopen( "$admindir/.htpasswd", "w+" ); 
		 		 $str = "$usernamenew:$passwordnew"; 
		 		 $len = strlen( $str ); 
		 		  
				 $str_gen = "AuthUserFile $admindir/.htpasswd\nAuthGroupFile /dev/null\nAuthName \"PHP CLASSIFIEDS\"\nAuthType Basic\n<Limit GET>\nrequire user $usernamenew\n</Limit>";				 
				 $len_gen = strlen( $str_gen );
				 fwrite( $fd, $str_gen, $len_gen );
				 fwrite( $fd2, $str, $len ); 
		 		 fclose( $fd );
				 fclose( $fd2 ); 
				 
				 print("If you did not recieve any errors, NICE");
				 print("<br><a href='install.php?level=5'>Next step</a>.");
				 
				 
			}
			
			else
			{
			 		print("No username and/or password given....");
			}
		}
}
	 
// -------------------- Step 5	Finished	------------------	 
if ($level==5)
{
	?>
	<b>FINISHED!</b>
	<p>PHP CLASSIFIEDS is now almost completely installed. To finish, you <b>must</b>go to <a href="admin/setconfig.php">Setconfig</a>, and save your settings in order to initialize the program !<p> 
	You can access <a href="admin/">the admin</a> directory to administer the program further, or see your pages at <a href="index.php">your classified</a> pages.<br>
Remember to first check if you are asked for username and password when accessing admin dir. If you are not asked for this, anyone can access and use your admin pages. Another important thing is to delete your install file. If this is not deleted, your passwordprotection has NO use, and everyone can access your admin panel.
	</p>
	<?
}	 
	


?>
</td>
</tr>
</table>
</body>
</html>
