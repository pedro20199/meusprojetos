<?

require ("config/config.inc.php");

if ($userid AND $pass)
{
	
	if (!$siteid)
	{
		$sql_select = "select * from $usr_tbl where userid = $userid AND pass = '$pass'";
		$result_s = mysql_query ($sql_select);
		
		if ($debug)
		{
		 print("$sql_select");
		}
		
		$num_hits =  mysql_num_rows($result_s);
		
	}
	
	elseif ($siteid)
	{
	
		
		
		$sql_select = "select * from $ads_tbl, $usr_tbl where $ads_tbl.sites_userid = $usr_tbl.userid AND $usr_tbl.userid = $userid AND $usr_tbl.pass = '$pass' AND $ads_tbl.siteid=$siteid";
		
		if ($debug)
		{
			print("$sql_select");
		}
		$result = mysql_query ($sql_select);
		
		$num_hits =  mysql_num_rows($result);
		
		  $result = mysql_query ($sql_select);


        	while ($row = mysql_fetch_array($result))
        	{


        		$siteid = $row["siteid"];
        		$sitetitle = $row["sitetitle"];
        		$sitedescription = $row["sitedescription"];
        		$siteurl = $row["siteurl"];
        		$sitedate = $row["sitedate"];
        		$sitecatid = $row["sitecatid"];
        		$sitehits = $row["sitehits"];
        		$sitevotes = $row["sitevotes"];
        		$custom_field_1 = $row["custom_field_1"];
        		$custom_field_2 = $row["custom_field_2"];
        		$custom_field_3 = $row["custom_field_3"];
        		$custom_field_4 = $row["custom_field_4"];
        		$custom_field_5 = $row["custom_field_5"];
        		$custom_field_6 = $row["custom_field_6"];
        		$custom_field_7 = $row["custom_field_7"];
        		$custom_field_8 = $row["custom_field_8"];
		}
		
		
	
	}
}


?>