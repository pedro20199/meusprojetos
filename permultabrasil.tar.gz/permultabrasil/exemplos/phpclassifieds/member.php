<?
session_start();
require("config/header.inc.php");
require("config/config.inc.php");
require("functions.php");
if (!$special_mode)
{ print("$menu_ordinary<p>"); }
print("<h3>$name_of_site</h3>");
check_valid_user();
print "<font class='text'>$la_member_area_welcome</font><p>";
print "<table border='1' cellpadding='2' width='100%' bgcolor='#DDDDDD' bordercolordark='#FFFFFF'>";
print "<tr>";
print "<td><font face='Verdana' size='1'><b>$la_admmenu</b></font></td>";
print "<td>&nbsp;</td>";
print "<td align='right'><font face='Verdana' size='1'>$la_logged_in: $valid_user</font></td>";
print "</tr>";
print "<tr>";
print "<td><a href='member.php'><font face='Verdana' size='1'><b>$la_admin_frontpage</b></font></a></td>";
print "<td><a href='change.php'><font face='Verdana' size='1'><b>$change_user</b></font></a></td>";
print "<td><a href='pass.php'><font face='Verdana' size='1'><b>$la_change_pass</b></font></a></td>";
print "</tr>";
print "</table>";

if ($deleteid)
{
 	 delete_ads($deleteid);
}
?>


<!-- OLD -->
<table border="1" cellspacing="1" width="100%" bordercolordark="#FFFFFF">
<tr>
    <td width="100%" bgcolor="#EAEAEA">
		<b><font class='text'><? echo $la_new_ad ?><br></font></b>
		<font class='text'><? echo $la_new_ad_info ?></font><br>
<?
$frontpage=2; 
include("catcol.php"); 
?>
			</td>
</tr>
</table>
<p>
<p>
<table border="0" cellpadding="2" cellspacing="2" width="100%">
<tr>
  <td bgcolor="#E6E6E6"><font class='text'><? echo $title ?></td>
  <td bgcolor="#E6E6E6"><font class='text'><? echo $category ?></td>
  <td bgcolor="#E6E6E6"><font class='text'><? echo $modify ?></td>
	<td bgcolor="#E6E6E6"><font class='text'>Delete</td>
</tr>
<?
//$sql_select = "select siteid,sitetitle,sitedescription,sitedate,sitecatid,sitehits,sitevotes, catid, catname, sites_userid, userid, pass from $cat_tbl, $ads_tbl, $usr_tbl where catid=sitecatid AND userid = '$userid' AND sites_userid=userid AND pass = '$pass'";
$sql_select = "select * from $cat_tbl, $ads_tbl, $usr_tbl where catid=sitecatid AND email = '$valid_user' AND ad_username = email";
$result = mysql_query ($sql_select);
while ($row = mysql_fetch_array($result))
{
 $siteid = $row["siteid"];
 $sitetitle = $row["sitetitle"];
 $sitedescription = $row["sitedescription"];
 $siteurl = $row["siteurl"];
 $sitedate = $row["sitedate"];
 $sitecatid = $row["sitecatid"];
 $sitehits = $row["sitehits"];
 $sitevotes = $row["sitevotes"];
 $catid = $row["catid"];
 $catname = $row["catname"];

print "<tr>";
print "<td width='30%'><font class='text'>$sitetitle</td>";
print "<td width='17%'><font class='text'>$catname</a></td>";
print "<td width='17%'><font class='text'><a href='add_ad.php?siteid=$siteid&update_rq=1'><u>$changedelete</u></a></td>";
print "<td width='17%'><font class='text'><a href='member.php?deleteid=$siteid'><u>Delete</u></a></td>";
print "</tr>";
}
print "</table>";
require("config/footer.inc.php");
?>