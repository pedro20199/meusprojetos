<html>
<head>
</head>

<body>
<?
require("config/config.inc.php");	
print("<img src='get.php?id=$id' alt='Stort bilde'>");
?>
<br><a href="javascript:window.close();"><? echo $la_large_picture_close ?></a>

</body>
</html>
