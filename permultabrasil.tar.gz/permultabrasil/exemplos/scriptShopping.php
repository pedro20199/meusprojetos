<!-- 
Nome do Script: SCRIPT LIVRE - Mini Shopping
Data Desenvolvimento: 07/12/2005
Desenvolvedor: Bruno Henrique Yoshimura (www.linkgratis.com.br), participante do programa MercadoSocio.
(O programa desenvolvido foi uma adapta��o de c�digos fornecidos por outros membros do MercadoS�cio)
 
--------------------------------------------------------------------------------------------------------

Vari�veis de entrada (GET):
  - "categoria" = categoria a ser buscada
  - "keyword" = palavra(s) chaves separadas por sinal "+" (exemplo: "camera+digital+sony")
  - "preco" = preco minimo do produto
  - "SITE_ID" = O seu site ID 
  - max =  N�mero m�ximo de produtos a serem listados (Preferencialmente 3 em 3)

Aten��o!!! Para mostrar mais do que 10 produtos, entre em contato com o suporte do MercadoS�cio.

Exemplos de uso:
  -> http://www.seusite.com.br/scriptShopping.php?categoria=1042&keyword=camera+digital&max=3
  -> http://www.seusite.com.br/scriptShopping.php?keyword=camera+digital&max=9
  -> http://www.seusite.com.br/scriptShopping.php?keyword=sony+cybershot&preco=200&pais=MLB

Para modificar as cores da publicidade modifique diretamente no CSS.
 - A fonte e a cor do link esta no CSS ".tahoma"

Sugest�es:
 - Ajuste o script para ficar em um iframe. Para ajustar a largura, trabalhe com a vari�vel limiteChar, que limita o n�mero de caracteres do titulo
 - Procure utilizar ao m�ximo a segmenta��o de an�ncio, por exemplo, se seu site � sobre animais, mostre publicidades sobre pet shop.

Esta segmenta��o � o principal objetivo deste tido de publicidade XML. 
 - Crie um siteId para cada banner, se poss�vel. Desta forma voc� pdoer� analisar qual a melhor publicidade para determinada �rea do site
 
Voc� poder� editar o c�digo e fazer algumas mudan�as, principalmente na busca XML da linha 158 deste c�digo. 
Nesta linha voc� poder� inserir filtros e outros recursos. Veja mais no portal MercadoSocio

--------------------------------------------------------------------------------------------------------
Ap�s rodar o c�digo e funcionar, pode remover este coment�rio. Desejo boas vendas!!!!

N�o se esque�a de contribuir com a comunidade MercadoS�cio, � muito importante a colabora�� ode todos desenvolvedores.
Caso tenha alguma melhoria neste c�digo, pode inserir. Eu fiz uma vers�o b�sica para aqueles que n�o conhecem a ferramenta XML.
-->

<?
$id_categ=$HTTP_GET_VARS[categoria];
$buscar=$HTTP_GET_VARS[keyword];
$pais=strtoupper($HTTP_GET_VARS[pais]);
$preco=$HTTP_GET_VARS[preco];
$max=$HTTP_GET_VARS[max];
$siteID="XXXXXXX";
 
switch ($pais) {
case "MLB":
    $dominio="www.mercadolivre.com.br";
    break;
case "MLP":
    $dominio="www.mercadolibre.com.pe";
    break;
default:
    $dominio="www.mercadolivre.com.br";
}?>
<html>
<head>
<style type="text/css">
a:link {
	font-family: Tahoma, Helvetica, sans-serif;
	text-decoration: none;
	color: #555555;
	font-size:  9px;
	font-weight: bold;
}
a:visited {
	font-family: Tahoma, Helvetica, sans-serif;
	text-decoration: none;
	color: #555555;
	font-size:  9px;
	font-weight: bold;
}
a:hover {
	font-family: Tahoma, Helvetica, sans-serif;
	text-decoration: underline;
	color: #555555;
	font-size:  9px;
	font-weight: bold;
}
a:active {
	font-family: Tahoma, Helvetica, sans-serif;
	text-decoration: none;
	color: #555555;
	font-size:  9px;
	font-weight: bold;
}
.precio {
	font-family: Tahoma, Helvetica, sans-serif;
	font-size: 9px;
	color: #CC0000;
</style>
</head>
<body topmargin="0" leftmargin="0" >
<dl>
  <table width="468" height="60" order="0" cellpadding="0" cellspacing="0" bgcolor="#ffffff" align="center"><tr>
      <?php

$insideitem = false;
$item = array();
$tag = "";
$title = "";
$link = "";
$price = "";
$image="";
$currency= "";
$count = 1;

function startElement($parser, $name, $attrs) {
	global $insideitem, $tag, $title, $link, $price, $image, $currency, $item, $count;
	if ($insideitem) {
		$tag = $name;
	} elseif ($name == "ITEM") {
		$insideitem = true;
	}
}

function endElement($parser, $name) {
	global $insideitem, $tag, $title, $link, $price, $image, $currency, $item, $attrs, $count, $max;
	if ($name == "ITEM") {
		echo "<td  align=\"center\" valign=\"middle\" style=\"padding:10px\">";
		echo "<img  width=\"90\" height=\"90\" src=\"".$image."\" align=\"center\" valign=\"middle\" >";
		echo "<div style=\"word-wrap: break-word; width:140px\"><a href=\"".$link."\" target=\"_blank\">".$title."</a><br><img height=\"3\" src=\"spacer.gif\" align=\"center\" valign=\"middle\" ><br>";
		echo "<font class=\"precio\">por apenas <b>".$currency.$price."<br></b></font></div></td></strong>";
		$title = "";
		$link = ""; 
		$price = "";
		$item = "";
		$image = "";
		$currency = "";
		$insideitem = false;
		$count = $count + 1;
		if ($count == 4)
		{
			echo "</tr><tr><td height=\"15px\"> </td></tr><tr>";
			$count = 1;
		}
	}
}

function characterData($parser, $data) {
	global $insideitem, $tag, $title, $link, $price, $image, $currency, $item, $attrs, $siteID;
	if ($insideitem) {
	switch ($tag) {
		case "ITEM":
		$id .= $item['ID'];
		break;
		case "TITLE":
		$title .= $data;
		break;
		case "LINK":
		$link .= str_replace("XXX",$siteID,$data); 
		break;
		case "PRICE":
		$price .= $data;
		break;
		case "IMAGE_URL":
		$image .= $data;
		break;
		case "CURRENCY":
		$currency .= $data;
		break;		
	}
	}
}
$xml_parser = xml_parser_create();
xml_set_element_handler($xml_parser, "startElement", "endElement");
xml_set_character_data_handler($xml_parser, "characterData");
$fp = fopen("http://".$dominio."/jm/searchXml?as_categ_id=".$id_categ."&as_word=".$buscar."&as_price_min=".$preco."&as_order_id=MAS_OFERTADOS&as_filtro_id=PRECIO_FIJO&as_display_type=G&noQCat=Y&as_qshow=".$max."","r")
	or die("Error reading data.");
while ($data = fread($fp, 4096))
	xml_parse($xml_parser, $data, feof($fp))
		or die(sprintf("XML error: %s at line %d", 
			xml_error_string(xml_get_error_code($xml_parser)), 
			xml_get_current_line_number($xml_parser)));
fclose($fp);
xml_parser_free($xml_parser);

?>
</tr>
<tr>
<td style="padding:10px" colspan="4" width="100%">
      <div align="center" style="font-family: tahoma; font-size:12px;"> 
       [ <a target="_blank" href="http://www.mercadolivre.com.br/jm/pms?site=".$siteID."&id=2021&as_opt=http://www.mercadolivre.com.br/jm/search?as_word=<? echo $buscar ?>$$as_price_min=<? echo $preco ?>$$as_categ_id=<? echo $id_categ ?>$$as_display_type=G$$as_order_id=MAS_OFERTADOS$$as_filtro_id=PRECIO_FIJO$$as_filtro_id2=MPAGO$$noQCat=Y"
         class="tahoma" style="color:CC0000; font-weight:bold">CONFIRA OUTRAS 
        OFERTAS</a>&nbsp;] <a target="_blank" href="http://www.mercadolivre.com.br/jm/pms?site=".$siteID."&id=2021&as_opt=http://www.mercadolivre.com.br/jm/search?as_word=<? echo $buscar ?>$$as_price_min=<? echo $preco ?>$$as_categ_id=<? echo $id_categ ?>$$as_display_type=G$$as_order_id=MAS_OFERTADOS$$as_filtro_id=PRECIO_FIJO$$as_filtro_id2=MPAGO$$noQCat=Y"
         class="tahoma" style="color:CC0000; font-weight:bold"></a></div>
</td>
</tr>
  </table>
</dl>
</body>
</html>
