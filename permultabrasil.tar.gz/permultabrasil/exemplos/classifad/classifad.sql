#
# Table structure for table 'classifad'
#
drop table if exists classifad;

CREATE TABLE classifad (
   adv_id int(5) NOT NULL auto_increment,
   poster text NULL,
   title text NOT NULL,
   description text NOT NULL,
   url text NULL,
   email varchar(255) NULL,
   posted_time int(14) NOT NULL,
   expires int(14) NOT NULL,
   remote_ip varchar(40) NOT NULL,
   category varchar(50) NOT NULL,
   PRIMARY KEY (adv_id)
);

