 Copyright (C) 2001  Michael de la Rue

 This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

This Classified Ads script uses a MySQL database for data storage.


FEATURES:

Customised appearance using templates.
Any number of easily configurable categories
Posters choose how many weeks to display their ad for.
A "new listings" front page with a drop-down selection of categories to choose from.
The script records a posters I.P. address, so that when he returns he is given the option of altering his ad, without having to remember a password, or have cookies enabled. Any ads posted by the visitor are listed with an "alter it" and "delete it" button beneath them. 
If an email address / url is given, the listing will include an EMAIL / SITE link at the bottom. If not, only the Title - Author <br> Description are shown.
The script automatically erases expired ads from the database.


INSTALL:

1:) Edit 'config.php' (variables).
2:) Edit 'top.php' and 'end.php' (html layout).
3:) Load 'classifad' table schema (MySQL).
4:) Upload & use.

- Alter the variables in config.php to reflect your setup.
- Edit top.php and end.php (the template files) to create a layout for your site. The output of the script will go between these. They should be html files - they are named .php so that the content doesn't get cached (in case you change them).
- The following must be included in the <head></head> section of your template (in top.php) . .   <link rel="stylesheet" type="text/css" href="classifad.css">
- You may alter the values in the stylesheet provided.
- Load the "classifad" table into your MySQL database (You will find the schema in classifad.sql)
- Upload the files to a directory on your php-enabled web server in ASCII.
- Go to index.php and try submitting an ad.


NOTES:

This release quite possibly has bugs depending on the setup of your server. I have tested it on my local server, and everything works, but you can have problems depending on the server. 

It probably works with php3, but I didn't write it with backwards compatibility in mind.

Feel free to modify and extend it. If you do this, please send me a copy. If you have bug reports email mice@hotpop.com.
