<?php


//Recebe os dados do formulario.
$apelido = $_POST['apelido'];
$email = $_POST['email'];
$senha = $_POST['senha'];

//faz a conexão com o banco de dados.
$conectar = mysqli_connect("localhost:3306","root","","permulta") // porta, usuario e senha
 or die("Erro ao fazer a conexão com a base de dados"); //caso não consiga conectar mostra a mensagem de erro mostrada na conexão
//Ajusta acomunicação entre o banco de dados e a Aplicação.
mysqli_set_charset($conectar,'utf8');
//String com consulta SQl da inserção.
$adiciona = "INSERT INTO usuarios (id,apelido,email,senha) VALUES (not null,'$apelido','$email','$senha')";
$adiciona_usuarios = mysqli_query($conectar, $adiciona);
?>
<?php

    //Destrói
    session_destroy();
    //Limpa
    unset ($_SESSION['email']);
    unset ($_SESSION['senha']);
    //Redireciona para a página de autenticão
    header('location:index.php');    



?>




