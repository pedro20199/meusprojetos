<?php
//Verifica se existe conexão com o banco de dados, caso não exista tenta criar uma nova.
$conectar = mysqli_connect("localhost:3306","root","","permulta") //Porta, usuário e senha.
or die("Erro ao fazer a conexão com o banco de dados"); //caso não consiga fazer a conexão mostra a mensagem de erro.

//Ajusta a o charset de comunicação entre a aplicação e o banco de dados.
mysqli_set_charset($conectar,'UTF-8');
?>
