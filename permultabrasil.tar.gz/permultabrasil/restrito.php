<?php
//A sessão precisa ser iniciada em cada página diferente.
if (!isset($_SESSION))    session_start();

//Verifica se não há variável da sessão que indentifica o usuário.
if (!isset($_SESSION['id'])){
//Destroi a sessão por segurança
   //session_destroy();
    //redireciona a pagina
    header("Location: principalrestrito.php"); exit;
}
?>

